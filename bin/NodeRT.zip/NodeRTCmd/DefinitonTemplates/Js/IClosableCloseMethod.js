﻿cls.prototype.close = function close() {
}

