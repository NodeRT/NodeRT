﻿cls.prototype.@(TX.Uncap(Model.Name)) = function () {
}
