Windows.Foundation.Collections
=====
This addon wraps Windows.Foundation.Collections WinRT namespace.

Please see below the documantation from http://msdn.microsoft.com/en-us/library/windows/apps/Windows.Foundation.Collections.aspx
<iframe seamless  width="99%" height="100%" frameborder="0" marginheight="0" marginwidth="0" src="http://msdn.microsoft.com/en-us/library/windows/apps/Windows.Foundation.Collections.aspx">
</iframe>
