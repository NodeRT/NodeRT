Windows.Web.Http.Headers
=====
This addon wraps Windows.Web.Http.Headers WinRT namespace.

Please see below the documantation from http://msdn.microsoft.com/en-us/library/windows/apps/Windows.Web.Http.Headers.aspx
<iframe seamless  width="99%" height="100%" frameborder="0" marginheight="0" marginwidth="0" src="http://msdn.microsoft.com/en-us/library/windows/apps/Windows.Web.Http.Headers.aspx">
</iframe>
