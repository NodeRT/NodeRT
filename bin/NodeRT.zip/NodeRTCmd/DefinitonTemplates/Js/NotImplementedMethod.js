﻿cls.prototype.@(Model.Name) = function () {
}
