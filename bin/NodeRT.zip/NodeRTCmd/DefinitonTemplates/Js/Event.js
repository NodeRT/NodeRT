﻿@{
    @:cls.prototype.addListener = function addListener(eventName, callback){}
    @:cls.prototype.removeListener = function removeListener(eventName, callback){}
    @:cls.prototype.on = function on(eventName, callback){}
    @:cls.prototype.off = function off(eventName, callback){}
}