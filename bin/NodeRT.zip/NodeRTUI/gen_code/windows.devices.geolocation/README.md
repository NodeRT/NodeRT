Windows.Devices.Geolocation
=====
This addon wraps Windows.Devices.Geolocation WinRT namespace.

Please see below the documantation from http://msdn.microsoft.com/en-us/library/windows/apps/Windows.Devices.Geolocation.aspx
<iframe seamless  width="99%" height="100%" frameborder="0" marginheight="0" marginwidth="0" src="http://msdn.microsoft.com/en-us/library/windows/apps/Windows.Devices.Geolocation.aspx">
</iframe>
