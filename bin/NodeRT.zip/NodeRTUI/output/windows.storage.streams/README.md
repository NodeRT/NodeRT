Windows.Storage.Streams
=====
This addon wraps Windows.Storage.Streams WinRT namespace.

Please see below the documantation from http://msdn.microsoft.com/en-us/library/windows/apps/Windows.Storage.Streams.aspx
<iframe seamless  width="99%" height="100%" frameborder="0" marginheight="0" marginwidth="0" src="http://msdn.microsoft.com/en-us/library/windows/apps/Windows.Storage.Streams.aspx">
</iframe>
