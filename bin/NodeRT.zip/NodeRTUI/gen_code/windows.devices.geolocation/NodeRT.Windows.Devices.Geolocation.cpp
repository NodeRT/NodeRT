// Copyright (c) Microsoft Corporation
// All rights reserved. 
//
// Licensed under the Apache License, Version 2.0 (the ""License""); you may not use this file except in compliance with the License. You may obtain a copy of the License at http://www.apache.org/licenses/LICENSE-2.0 
//
// THIS CODE IS PROVIDED ON AN  *AS IS* BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION ANY IMPLIED WARRANTIES OR CONDITIONS OF TITLE, FITNESS FOR A PARTICULAR PURPOSE, MERCHANTABLITY OR NON-INFRINGEMENT. 
//
// See the Apache Version 2.0 License for specific language governing permissions and limitations under the License.

#define NTDDI_VERSION 0x06010000

#include <v8.h>
#include <string>

#include "node_object_wrap.h"
#include "WrapperBase.h"
#include "OpaqueWrapper.h"
#include "node-async.h"
#include "NodeRtUtils.h"
#include "CollectionsWrap.h"

#include <ppltasks.h>

#using <Windows.WinMD>

// this undefs fixes the issues of compiling Windows.Data.Json, Windows.Storag.FileProperties, and Windows.Stroage.Search
// Some of the node header files brings windows definitions with the same names as some of the WinRT methods
#undef DocumentProperties
#undef GetObject
#undef CreateEvent
#undef FindText

const char* REGISTRATION_TOKEN_MAP_PROPERTY_NAME = "__registrationTokenMap__";

using namespace v8;
using namespace node;
using namespace concurrency;

namespace NodeRT { namespace Windows { namespace Devices { namespace Geolocation { 
  v8::Handle<v8::Value> WrapIGeoshape(::Windows::Devices::Geolocation::IGeoshape^ wintRtInstance);
  ::Windows::Devices::Geolocation::IGeoshape^ UnwrapIGeoshape(Handle<Value> value);
  
  v8::Handle<v8::Value> WrapGeopoint(::Windows::Devices::Geolocation::Geopoint^ wintRtInstance);
  ::Windows::Devices::Geolocation::Geopoint^ UnwrapGeopoint(Handle<Value> value);
  
  v8::Handle<v8::Value> WrapGeocoordinateSatelliteData(::Windows::Devices::Geolocation::GeocoordinateSatelliteData^ wintRtInstance);
  ::Windows::Devices::Geolocation::GeocoordinateSatelliteData^ UnwrapGeocoordinateSatelliteData(Handle<Value> value);
  
  v8::Handle<v8::Value> WrapGeocoordinate(::Windows::Devices::Geolocation::Geocoordinate^ wintRtInstance);
  ::Windows::Devices::Geolocation::Geocoordinate^ UnwrapGeocoordinate(Handle<Value> value);
  
  v8::Handle<v8::Value> WrapCivicAddress(::Windows::Devices::Geolocation::CivicAddress^ wintRtInstance);
  ::Windows::Devices::Geolocation::CivicAddress^ UnwrapCivicAddress(Handle<Value> value);
  
  v8::Handle<v8::Value> WrapGeoposition(::Windows::Devices::Geolocation::Geoposition^ wintRtInstance);
  ::Windows::Devices::Geolocation::Geoposition^ UnwrapGeoposition(Handle<Value> value);
  
  v8::Handle<v8::Value> WrapPositionChangedEventArgs(::Windows::Devices::Geolocation::PositionChangedEventArgs^ wintRtInstance);
  ::Windows::Devices::Geolocation::PositionChangedEventArgs^ UnwrapPositionChangedEventArgs(Handle<Value> value);
  
  v8::Handle<v8::Value> WrapStatusChangedEventArgs(::Windows::Devices::Geolocation::StatusChangedEventArgs^ wintRtInstance);
  ::Windows::Devices::Geolocation::StatusChangedEventArgs^ UnwrapStatusChangedEventArgs(Handle<Value> value);
  
  v8::Handle<v8::Value> WrapGeolocator(::Windows::Devices::Geolocation::Geolocator^ wintRtInstance);
  ::Windows::Devices::Geolocation::Geolocator^ UnwrapGeolocator(Handle<Value> value);
  
  v8::Handle<v8::Value> WrapGeocircle(::Windows::Devices::Geolocation::Geocircle^ wintRtInstance);
  ::Windows::Devices::Geolocation::Geocircle^ UnwrapGeocircle(Handle<Value> value);
  


  static v8::Handle<v8::Value> InitPositionAccuracyEnum(const Handle<Object> exports)
  {
    HandleScope scope;
    
    Handle<Object> enumObject = Object::New();
    exports->Set(String::NewSymbol("PositionAccuracy"), enumObject);

    enumObject->Set(String::NewSymbol("default"), Integer::New(0));
    enumObject->Set(String::NewSymbol("high"), Integer::New(1));

    return scope.Close(Undefined());
  }


  static v8::Handle<v8::Value> InitPositionStatusEnum(const Handle<Object> exports)
  {
    HandleScope scope;
    
    Handle<Object> enumObject = Object::New();
    exports->Set(String::NewSymbol("PositionStatus"), enumObject);

    enumObject->Set(String::NewSymbol("ready"), Integer::New(0));
    enumObject->Set(String::NewSymbol("initializing"), Integer::New(1));
    enumObject->Set(String::NewSymbol("noData"), Integer::New(2));
    enumObject->Set(String::NewSymbol("disabled"), Integer::New(3));
    enumObject->Set(String::NewSymbol("notInitialized"), Integer::New(4));
    enumObject->Set(String::NewSymbol("notAvailable"), Integer::New(5));

    return scope.Close(Undefined());
  }


  static v8::Handle<v8::Value> InitPositionSourceEnum(const Handle<Object> exports)
  {
    HandleScope scope;
    
    Handle<Object> enumObject = Object::New();
    exports->Set(String::NewSymbol("PositionSource"), enumObject);

    enumObject->Set(String::NewSymbol("cellular"), Integer::New(0));
    enumObject->Set(String::NewSymbol("satellite"), Integer::New(1));
    enumObject->Set(String::NewSymbol("wiFi"), Integer::New(2));
    enumObject->Set(String::NewSymbol("iPAddress"), Integer::New(3));
    enumObject->Set(String::NewSymbol("unknown"), Integer::New(4));

    return scope.Close(Undefined());
  }


  static v8::Handle<v8::Value> InitGeoshapeTypeEnum(const Handle<Object> exports)
  {
    HandleScope scope;
    
    Handle<Object> enumObject = Object::New();
    exports->Set(String::NewSymbol("GeoshapeType"), enumObject);

    enumObject->Set(String::NewSymbol("geopoint"), Integer::New(0));
    enumObject->Set(String::NewSymbol("geocircle"), Integer::New(1));

    return scope.Close(Undefined());
  }


  static v8::Handle<v8::Value> InitAltitudeReferenceSystemEnum(const Handle<Object> exports)
  {
    HandleScope scope;
    
    Handle<Object> enumObject = Object::New();
    exports->Set(String::NewSymbol("AltitudeReferenceSystem"), enumObject);

    enumObject->Set(String::NewSymbol("unspecified"), Integer::New(0));
    enumObject->Set(String::NewSymbol("terrain"), Integer::New(1));
    enumObject->Set(String::NewSymbol("ellipsoid"), Integer::New(2));
    enumObject->Set(String::NewSymbol("geoid"), Integer::New(3));
    enumObject->Set(String::NewSymbol("surface"), Integer::New(4));

    return scope.Close(Undefined());
  }



  
  static bool IsBasicGeopositionJsObject(Handle<Value> value)
  {
    if (!value->IsObject())
    {
      return false;
    }

    Handle<String> symbol;
    Handle<Object> obj = value.As<Object>();

    symbol = String::NewSymbol("latitude");
    if (obj->Has(symbol))
    {
      if (!obj->Get(symbol)->IsNumber())
      {
          return false;
      }
    }
    
    symbol = String::NewSymbol("longitude");
    if (obj->Has(symbol))
    {
      if (!obj->Get(symbol)->IsNumber())
      {
          return false;
      }
    }
    
    symbol = String::NewSymbol("altitude");
    if (obj->Has(symbol))
    {
      if (!obj->Get(symbol)->IsNumber())
      {
          return false;
      }
    }
    
    return true;
  }

  ::Windows::Devices::Geolocation::BasicGeoposition BasicGeopositionFromJsObject(Handle<Value> value)
  {
    HandleScope scope;
    ::Windows::Devices::Geolocation::BasicGeoposition returnValue;
    
    if (!value->IsObject())
    {
      ThrowException(Exception::TypeError(NodeRT::Utils::NewString(L"Unexpected type, expected an object")));
      return returnValue;
    }

    Handle<Object> obj = value.As<Object>();
    Handle<String> symbol;

    symbol = String::NewSymbol("latitude");
    if (obj->Has(symbol))
    {
      returnValue.Latitude = obj->Get(symbol)->NumberValue();
    }
    
    symbol = String::NewSymbol("longitude");
    if (obj->Has(symbol))
    {
      returnValue.Longitude = obj->Get(symbol)->NumberValue();
    }
    
    symbol = String::NewSymbol("altitude");
    if (obj->Has(symbol))
    {
      returnValue.Altitude = obj->Get(symbol)->NumberValue();
    }
    
    return returnValue;
  }

  Handle<Value> BasicGeopositionToJsObject(::Windows::Devices::Geolocation::BasicGeoposition value)
  {
    HandleScope scope;

    Handle<Object> obj = Object::New();

    obj->Set(String::NewSymbol("latitude"), Number::New(static_cast<double>(value.Latitude)));
    obj->Set(String::NewSymbol("longitude"), Number::New(static_cast<double>(value.Longitude)));
    obj->Set(String::NewSymbol("altitude"), Number::New(static_cast<double>(value.Altitude)));
    
    return scope.Close(obj);
  }

  
  class IGeoshape : public WrapperBase
  {
  public:    
    static v8::Handle<v8::Value> Init(const Handle<Object> exports)
    {
      HandleScope scope;
      
      s_constructorTemplate = Persistent<FunctionTemplate>::New(FunctionTemplate::New(New));
      s_constructorTemplate->SetClassName(String::NewSymbol("IGeoshape"));
      s_constructorTemplate->InstanceTemplate()->SetInternalFieldCount(1);
      
                              
      s_constructorTemplate->PrototypeTemplate()->SetAccessor(String::NewSymbol("altitudeReferenceSystem"), AltitudeReferenceSystemGetter);
      s_constructorTemplate->PrototypeTemplate()->SetAccessor(String::NewSymbol("geoshapeType"), GeoshapeTypeGetter);
      s_constructorTemplate->PrototypeTemplate()->SetAccessor(String::NewSymbol("spatialReferenceId"), SpatialReferenceIdGetter);
      
      Local<Function> constructor = s_constructorTemplate->GetFunction();


      exports->Set(String::NewSymbol("IGeoshape"), constructor);
      return scope.Close(Undefined());
    }


    virtual ::Platform::Object^ GetObjectInstance() const override
    {
      return _instance;
    }

  private:
    
    IGeoshape(::Windows::Devices::Geolocation::IGeoshape^ instance)
    {
      _instance = instance;
    }
    
    
    static v8::Handle<v8::Value> New(const v8::Arguments& args)
    {
      HandleScope scope;
      
      ::Windows::Devices::Geolocation::IGeoshape^ winRtInstance;


      if (args.Length() == 1 && OpaqueWrapper::IsOpaqueWrapper(args[0]) &&
        NodeRT::Utils::IsWinRtWrapperOf<::Windows::Devices::Geolocation::IGeoshape^>(args[0]))
      {
        try 
        {
          winRtInstance = (::Windows::Devices::Geolocation::IGeoshape^) NodeRT::Utils::GetObjectInstance(args[0]);
        }
        catch (Platform::Exception ^exception)
        {
          NodeRT::Utils::ThrowWinRtExceptionInJs(exception);
          return scope.Close(Undefined());
        }
      }
      else
      {
        ThrowException(Exception::Error(NodeRT::Utils::NewString(L"Invalid arguments, no suitable constructor found")));
        return scope.Close(Undefined());
      }

      args.This()->SetHiddenValue(String::NewSymbol("__winRtInstance__"), True());

      IGeoshape *wrapperInstance = new IGeoshape(winRtInstance);
      wrapperInstance->Wrap(args.This());

      return args.This();
    }


  



    static Handle<Value> AltitudeReferenceSystemGetter(Local<String> property, const AccessorInfo &info)
    {
      HandleScope scope;
      
      if (!NodeRT::Utils::IsWinRtWrapperOf<::Windows::Devices::Geolocation::IGeoshape^>(info.This()))
      {
        return scope.Close(Undefined());
      }

      IGeoshape *wrapper = IGeoshape::Unwrap<IGeoshape>(info.This());

      try 
      {
        ::Windows::Devices::Geolocation::AltitudeReferenceSystem result = wrapper->_instance->AltitudeReferenceSystem;
        return scope.Close(Integer::New(static_cast<int>(result)));
      }
      catch (Platform::Exception ^exception)
      {
        NodeRT::Utils::ThrowWinRtExceptionInJs(exception);
        return scope.Close(Undefined());
      }
    }
    
    static Handle<Value> GeoshapeTypeGetter(Local<String> property, const AccessorInfo &info)
    {
      HandleScope scope;
      
      if (!NodeRT::Utils::IsWinRtWrapperOf<::Windows::Devices::Geolocation::IGeoshape^>(info.This()))
      {
        return scope.Close(Undefined());
      }

      IGeoshape *wrapper = IGeoshape::Unwrap<IGeoshape>(info.This());

      try 
      {
        ::Windows::Devices::Geolocation::GeoshapeType result = wrapper->_instance->GeoshapeType;
        return scope.Close(Integer::New(static_cast<int>(result)));
      }
      catch (Platform::Exception ^exception)
      {
        NodeRT::Utils::ThrowWinRtExceptionInJs(exception);
        return scope.Close(Undefined());
      }
    }
    
    static Handle<Value> SpatialReferenceIdGetter(Local<String> property, const AccessorInfo &info)
    {
      HandleScope scope;
      
      if (!NodeRT::Utils::IsWinRtWrapperOf<::Windows::Devices::Geolocation::IGeoshape^>(info.This()))
      {
        return scope.Close(Undefined());
      }

      IGeoshape *wrapper = IGeoshape::Unwrap<IGeoshape>(info.This());

      try 
      {
        unsigned int result = wrapper->_instance->SpatialReferenceId;
        return scope.Close(Integer::New(result));
      }
      catch (Platform::Exception ^exception)
      {
        NodeRT::Utils::ThrowWinRtExceptionInJs(exception);
        return scope.Close(Undefined());
      }
    }
    


  private:
    ::Windows::Devices::Geolocation::IGeoshape^ _instance;
    static Persistent<FunctionTemplate> s_constructorTemplate;

    friend v8::Handle<v8::Value> WrapIGeoshape(::Windows::Devices::Geolocation::IGeoshape^ wintRtInstance);
    friend ::Windows::Devices::Geolocation::IGeoshape^ UnwrapIGeoshape(Handle<Value> value);
    friend bool IsIGeoshapeWrapper(Handle<Value> value);
  };
  Persistent<FunctionTemplate> IGeoshape::s_constructorTemplate;

  v8::Handle<v8::Value> WrapIGeoshape(::Windows::Devices::Geolocation::IGeoshape^ winRtInstance)
  {
    HandleScope scope;

    if (winRtInstance == nullptr)
    {
      return scope.Close(Undefined());
    }

    Handle<Object> opaqueWrapper = CreateOpaqueWrapper(winRtInstance);
    Handle<Value> args[] = {opaqueWrapper};
    return scope.Close(IGeoshape::s_constructorTemplate->GetFunction()->NewInstance(_countof(args), args));
  }

  ::Windows::Devices::Geolocation::IGeoshape^ UnwrapIGeoshape(Handle<Value> value)
  {
     return IGeoshape::Unwrap<IGeoshape>(value.As<Object>())->_instance;
  }

  void InitIGeoshape(Handle<Object> exports)
  {
    IGeoshape::Init(exports);
  }

  class Geopoint : public WrapperBase
  {
  public:    
    static v8::Handle<v8::Value> Init(const Handle<Object> exports)
    {
      HandleScope scope;
      
      s_constructorTemplate = Persistent<FunctionTemplate>::New(FunctionTemplate::New(New));
      s_constructorTemplate->SetClassName(String::NewSymbol("Geopoint"));
      s_constructorTemplate->InstanceTemplate()->SetInternalFieldCount(1);
      
                              
      s_constructorTemplate->PrototypeTemplate()->SetAccessor(String::NewSymbol("position"), PositionGetter);
      s_constructorTemplate->PrototypeTemplate()->SetAccessor(String::NewSymbol("altitudeReferenceSystem"), AltitudeReferenceSystemGetter);
      s_constructorTemplate->PrototypeTemplate()->SetAccessor(String::NewSymbol("geoshapeType"), GeoshapeTypeGetter);
      s_constructorTemplate->PrototypeTemplate()->SetAccessor(String::NewSymbol("spatialReferenceId"), SpatialReferenceIdGetter);
      
      Local<Function> constructor = s_constructorTemplate->GetFunction();


      exports->Set(String::NewSymbol("Geopoint"), constructor);
      return scope.Close(Undefined());
    }


    virtual ::Platform::Object^ GetObjectInstance() const override
    {
      return _instance;
    }

  private:
    
    Geopoint(::Windows::Devices::Geolocation::Geopoint^ instance)
    {
      _instance = instance;
    }
    
    
    static v8::Handle<v8::Value> New(const v8::Arguments& args)
    {
      HandleScope scope;
      
      ::Windows::Devices::Geolocation::Geopoint^ winRtInstance;


      if (args.Length() == 1 && OpaqueWrapper::IsOpaqueWrapper(args[0]) &&
        NodeRT::Utils::IsWinRtWrapperOf<::Windows::Devices::Geolocation::Geopoint^>(args[0]))
      {
        try 
        {
          winRtInstance = (::Windows::Devices::Geolocation::Geopoint^) NodeRT::Utils::GetObjectInstance(args[0]);
        }
        catch (Platform::Exception ^exception)
        {
          NodeRT::Utils::ThrowWinRtExceptionInJs(exception);
          return scope.Close(Undefined());
        }
      }
      else if (args.Length() == 1
        && IsBasicGeopositionJsObject(args[0]))
      {
        try
        {
          ::Windows::Devices::Geolocation::BasicGeoposition arg0 = BasicGeopositionFromJsObject(args[0]);
          
          winRtInstance = ref new ::Windows::Devices::Geolocation::Geopoint(arg0);
        }
        catch (Platform::Exception ^exception)
        {
          NodeRT::Utils::ThrowWinRtExceptionInJs(exception);
          return scope.Close(Undefined());
        }
      }
      else if (args.Length() == 2
        && IsBasicGeopositionJsObject(args[0])
        && args[1]->IsInt32())
      {
        try
        {
          ::Windows::Devices::Geolocation::BasicGeoposition arg0 = BasicGeopositionFromJsObject(args[0]);
          ::Windows::Devices::Geolocation::AltitudeReferenceSystem arg1 = static_cast<::Windows::Devices::Geolocation::AltitudeReferenceSystem>(args[1]->Int32Value());
          
          winRtInstance = ref new ::Windows::Devices::Geolocation::Geopoint(arg0,arg1);
        }
        catch (Platform::Exception ^exception)
        {
          NodeRT::Utils::ThrowWinRtExceptionInJs(exception);
          return scope.Close(Undefined());
        }
      }
      else if (args.Length() == 3
        && IsBasicGeopositionJsObject(args[0])
        && args[1]->IsInt32()
        && args[2]->IsUint32())
      {
        try
        {
          ::Windows::Devices::Geolocation::BasicGeoposition arg0 = BasicGeopositionFromJsObject(args[0]);
          ::Windows::Devices::Geolocation::AltitudeReferenceSystem arg1 = static_cast<::Windows::Devices::Geolocation::AltitudeReferenceSystem>(args[1]->Int32Value());
          unsigned int arg2 = static_cast<unsigned int>(args[2]->IntegerValue());
          
          winRtInstance = ref new ::Windows::Devices::Geolocation::Geopoint(arg0,arg1,arg2);
        }
        catch (Platform::Exception ^exception)
        {
          NodeRT::Utils::ThrowWinRtExceptionInJs(exception);
          return scope.Close(Undefined());
        }
      }
      else
      {
        ThrowException(Exception::Error(NodeRT::Utils::NewString(L"Invalid arguments, no suitable constructor found")));
        return scope.Close(Undefined());
      }

      args.This()->SetHiddenValue(String::NewSymbol("__winRtInstance__"), True());

      Geopoint *wrapperInstance = new Geopoint(winRtInstance);
      wrapperInstance->Wrap(args.This());

      return args.This();
    }


  



    static Handle<Value> PositionGetter(Local<String> property, const AccessorInfo &info)
    {
      HandleScope scope;
      
      if (!NodeRT::Utils::IsWinRtWrapperOf<::Windows::Devices::Geolocation::Geopoint^>(info.This()))
      {
        return scope.Close(Undefined());
      }

      Geopoint *wrapper = Geopoint::Unwrap<Geopoint>(info.This());

      try 
      {
        ::Windows::Devices::Geolocation::BasicGeoposition result = wrapper->_instance->Position;
        return scope.Close(BasicGeopositionToJsObject(result));
      }
      catch (Platform::Exception ^exception)
      {
        NodeRT::Utils::ThrowWinRtExceptionInJs(exception);
        return scope.Close(Undefined());
      }
    }
    
    static Handle<Value> AltitudeReferenceSystemGetter(Local<String> property, const AccessorInfo &info)
    {
      HandleScope scope;
      
      if (!NodeRT::Utils::IsWinRtWrapperOf<::Windows::Devices::Geolocation::Geopoint^>(info.This()))
      {
        return scope.Close(Undefined());
      }

      Geopoint *wrapper = Geopoint::Unwrap<Geopoint>(info.This());

      try 
      {
        ::Windows::Devices::Geolocation::AltitudeReferenceSystem result = wrapper->_instance->AltitudeReferenceSystem;
        return scope.Close(Integer::New(static_cast<int>(result)));
      }
      catch (Platform::Exception ^exception)
      {
        NodeRT::Utils::ThrowWinRtExceptionInJs(exception);
        return scope.Close(Undefined());
      }
    }
    
    static Handle<Value> GeoshapeTypeGetter(Local<String> property, const AccessorInfo &info)
    {
      HandleScope scope;
      
      if (!NodeRT::Utils::IsWinRtWrapperOf<::Windows::Devices::Geolocation::Geopoint^>(info.This()))
      {
        return scope.Close(Undefined());
      }

      Geopoint *wrapper = Geopoint::Unwrap<Geopoint>(info.This());

      try 
      {
        ::Windows::Devices::Geolocation::GeoshapeType result = wrapper->_instance->GeoshapeType;
        return scope.Close(Integer::New(static_cast<int>(result)));
      }
      catch (Platform::Exception ^exception)
      {
        NodeRT::Utils::ThrowWinRtExceptionInJs(exception);
        return scope.Close(Undefined());
      }
    }
    
    static Handle<Value> SpatialReferenceIdGetter(Local<String> property, const AccessorInfo &info)
    {
      HandleScope scope;
      
      if (!NodeRT::Utils::IsWinRtWrapperOf<::Windows::Devices::Geolocation::Geopoint^>(info.This()))
      {
        return scope.Close(Undefined());
      }

      Geopoint *wrapper = Geopoint::Unwrap<Geopoint>(info.This());

      try 
      {
        unsigned int result = wrapper->_instance->SpatialReferenceId;
        return scope.Close(Integer::New(result));
      }
      catch (Platform::Exception ^exception)
      {
        NodeRT::Utils::ThrowWinRtExceptionInJs(exception);
        return scope.Close(Undefined());
      }
    }
    


  private:
    ::Windows::Devices::Geolocation::Geopoint^ _instance;
    static Persistent<FunctionTemplate> s_constructorTemplate;

    friend v8::Handle<v8::Value> WrapGeopoint(::Windows::Devices::Geolocation::Geopoint^ wintRtInstance);
    friend ::Windows::Devices::Geolocation::Geopoint^ UnwrapGeopoint(Handle<Value> value);
    friend bool IsGeopointWrapper(Handle<Value> value);
  };
  Persistent<FunctionTemplate> Geopoint::s_constructorTemplate;

  v8::Handle<v8::Value> WrapGeopoint(::Windows::Devices::Geolocation::Geopoint^ winRtInstance)
  {
    HandleScope scope;

    if (winRtInstance == nullptr)
    {
      return scope.Close(Undefined());
    }

    Handle<Object> opaqueWrapper = CreateOpaqueWrapper(winRtInstance);
    Handle<Value> args[] = {opaqueWrapper};
    return scope.Close(Geopoint::s_constructorTemplate->GetFunction()->NewInstance(_countof(args), args));
  }

  ::Windows::Devices::Geolocation::Geopoint^ UnwrapGeopoint(Handle<Value> value)
  {
     return Geopoint::Unwrap<Geopoint>(value.As<Object>())->_instance;
  }

  void InitGeopoint(Handle<Object> exports)
  {
    Geopoint::Init(exports);
  }

  class GeocoordinateSatelliteData : public WrapperBase
  {
  public:    
    static v8::Handle<v8::Value> Init(const Handle<Object> exports)
    {
      HandleScope scope;
      
      s_constructorTemplate = Persistent<FunctionTemplate>::New(FunctionTemplate::New(New));
      s_constructorTemplate->SetClassName(String::NewSymbol("GeocoordinateSatelliteData"));
      s_constructorTemplate->InstanceTemplate()->SetInternalFieldCount(1);
      
                              
      s_constructorTemplate->PrototypeTemplate()->SetAccessor(String::NewSymbol("horizontalDilutionOfPrecision"), HorizontalDilutionOfPrecisionGetter);
      s_constructorTemplate->PrototypeTemplate()->SetAccessor(String::NewSymbol("positionDilutionOfPrecision"), PositionDilutionOfPrecisionGetter);
      s_constructorTemplate->PrototypeTemplate()->SetAccessor(String::NewSymbol("verticalDilutionOfPrecision"), VerticalDilutionOfPrecisionGetter);
      
      Local<Function> constructor = s_constructorTemplate->GetFunction();


      exports->Set(String::NewSymbol("GeocoordinateSatelliteData"), constructor);
      return scope.Close(Undefined());
    }


    virtual ::Platform::Object^ GetObjectInstance() const override
    {
      return _instance;
    }

  private:
    
    GeocoordinateSatelliteData(::Windows::Devices::Geolocation::GeocoordinateSatelliteData^ instance)
    {
      _instance = instance;
    }
    
    
    static v8::Handle<v8::Value> New(const v8::Arguments& args)
    {
      HandleScope scope;
      
      ::Windows::Devices::Geolocation::GeocoordinateSatelliteData^ winRtInstance;


      if (args.Length() == 1 && OpaqueWrapper::IsOpaqueWrapper(args[0]) &&
        NodeRT::Utils::IsWinRtWrapperOf<::Windows::Devices::Geolocation::GeocoordinateSatelliteData^>(args[0]))
      {
        try 
        {
          winRtInstance = (::Windows::Devices::Geolocation::GeocoordinateSatelliteData^) NodeRT::Utils::GetObjectInstance(args[0]);
        }
        catch (Platform::Exception ^exception)
        {
          NodeRT::Utils::ThrowWinRtExceptionInJs(exception);
          return scope.Close(Undefined());
        }
      }
      else
      {
        ThrowException(Exception::Error(NodeRT::Utils::NewString(L"Invalid arguments, no suitable constructor found")));
        return scope.Close(Undefined());
      }

      args.This()->SetHiddenValue(String::NewSymbol("__winRtInstance__"), True());

      GeocoordinateSatelliteData *wrapperInstance = new GeocoordinateSatelliteData(winRtInstance);
      wrapperInstance->Wrap(args.This());

      return args.This();
    }


  



    static Handle<Value> HorizontalDilutionOfPrecisionGetter(Local<String> property, const AccessorInfo &info)
    {
      HandleScope scope;
      
      if (!NodeRT::Utils::IsWinRtWrapperOf<::Windows::Devices::Geolocation::GeocoordinateSatelliteData^>(info.This()))
      {
        return scope.Close(Undefined());
      }

      GeocoordinateSatelliteData *wrapper = GeocoordinateSatelliteData::Unwrap<GeocoordinateSatelliteData>(info.This());

      try 
      {
        ::Platform::IBox<double>^ result = wrapper->_instance->HorizontalDilutionOfPrecision;
        return scope.Close(result ? Number::New(static_cast<double>(result->Value)): static_cast<Handle<Value>>(Undefined()));
      }
      catch (Platform::Exception ^exception)
      {
        NodeRT::Utils::ThrowWinRtExceptionInJs(exception);
        return scope.Close(Undefined());
      }
    }
    
    static Handle<Value> PositionDilutionOfPrecisionGetter(Local<String> property, const AccessorInfo &info)
    {
      HandleScope scope;
      
      if (!NodeRT::Utils::IsWinRtWrapperOf<::Windows::Devices::Geolocation::GeocoordinateSatelliteData^>(info.This()))
      {
        return scope.Close(Undefined());
      }

      GeocoordinateSatelliteData *wrapper = GeocoordinateSatelliteData::Unwrap<GeocoordinateSatelliteData>(info.This());

      try 
      {
        ::Platform::IBox<double>^ result = wrapper->_instance->PositionDilutionOfPrecision;
        return scope.Close(result ? Number::New(static_cast<double>(result->Value)): static_cast<Handle<Value>>(Undefined()));
      }
      catch (Platform::Exception ^exception)
      {
        NodeRT::Utils::ThrowWinRtExceptionInJs(exception);
        return scope.Close(Undefined());
      }
    }
    
    static Handle<Value> VerticalDilutionOfPrecisionGetter(Local<String> property, const AccessorInfo &info)
    {
      HandleScope scope;
      
      if (!NodeRT::Utils::IsWinRtWrapperOf<::Windows::Devices::Geolocation::GeocoordinateSatelliteData^>(info.This()))
      {
        return scope.Close(Undefined());
      }

      GeocoordinateSatelliteData *wrapper = GeocoordinateSatelliteData::Unwrap<GeocoordinateSatelliteData>(info.This());

      try 
      {
        ::Platform::IBox<double>^ result = wrapper->_instance->VerticalDilutionOfPrecision;
        return scope.Close(result ? Number::New(static_cast<double>(result->Value)): static_cast<Handle<Value>>(Undefined()));
      }
      catch (Platform::Exception ^exception)
      {
        NodeRT::Utils::ThrowWinRtExceptionInJs(exception);
        return scope.Close(Undefined());
      }
    }
    


  private:
    ::Windows::Devices::Geolocation::GeocoordinateSatelliteData^ _instance;
    static Persistent<FunctionTemplate> s_constructorTemplate;

    friend v8::Handle<v8::Value> WrapGeocoordinateSatelliteData(::Windows::Devices::Geolocation::GeocoordinateSatelliteData^ wintRtInstance);
    friend ::Windows::Devices::Geolocation::GeocoordinateSatelliteData^ UnwrapGeocoordinateSatelliteData(Handle<Value> value);
    friend bool IsGeocoordinateSatelliteDataWrapper(Handle<Value> value);
  };
  Persistent<FunctionTemplate> GeocoordinateSatelliteData::s_constructorTemplate;

  v8::Handle<v8::Value> WrapGeocoordinateSatelliteData(::Windows::Devices::Geolocation::GeocoordinateSatelliteData^ winRtInstance)
  {
    HandleScope scope;

    if (winRtInstance == nullptr)
    {
      return scope.Close(Undefined());
    }

    Handle<Object> opaqueWrapper = CreateOpaqueWrapper(winRtInstance);
    Handle<Value> args[] = {opaqueWrapper};
    return scope.Close(GeocoordinateSatelliteData::s_constructorTemplate->GetFunction()->NewInstance(_countof(args), args));
  }

  ::Windows::Devices::Geolocation::GeocoordinateSatelliteData^ UnwrapGeocoordinateSatelliteData(Handle<Value> value)
  {
     return GeocoordinateSatelliteData::Unwrap<GeocoordinateSatelliteData>(value.As<Object>())->_instance;
  }

  void InitGeocoordinateSatelliteData(Handle<Object> exports)
  {
    GeocoordinateSatelliteData::Init(exports);
  }

  class Geocoordinate : public WrapperBase
  {
  public:    
    static v8::Handle<v8::Value> Init(const Handle<Object> exports)
    {
      HandleScope scope;
      
      s_constructorTemplate = Persistent<FunctionTemplate>::New(FunctionTemplate::New(New));
      s_constructorTemplate->SetClassName(String::NewSymbol("Geocoordinate"));
      s_constructorTemplate->InstanceTemplate()->SetInternalFieldCount(1);
      
                              
      s_constructorTemplate->PrototypeTemplate()->SetAccessor(String::NewSymbol("accuracy"), AccuracyGetter);
      s_constructorTemplate->PrototypeTemplate()->SetAccessor(String::NewSymbol("altitude"), AltitudeGetter);
      s_constructorTemplate->PrototypeTemplate()->SetAccessor(String::NewSymbol("altitudeAccuracy"), AltitudeAccuracyGetter);
      s_constructorTemplate->PrototypeTemplate()->SetAccessor(String::NewSymbol("heading"), HeadingGetter);
      s_constructorTemplate->PrototypeTemplate()->SetAccessor(String::NewSymbol("latitude"), LatitudeGetter);
      s_constructorTemplate->PrototypeTemplate()->SetAccessor(String::NewSymbol("longitude"), LongitudeGetter);
      s_constructorTemplate->PrototypeTemplate()->SetAccessor(String::NewSymbol("speed"), SpeedGetter);
      s_constructorTemplate->PrototypeTemplate()->SetAccessor(String::NewSymbol("timestamp"), TimestampGetter);
      s_constructorTemplate->PrototypeTemplate()->SetAccessor(String::NewSymbol("positionSource"), PositionSourceGetter);
      s_constructorTemplate->PrototypeTemplate()->SetAccessor(String::NewSymbol("satelliteData"), SatelliteDataGetter);
      s_constructorTemplate->PrototypeTemplate()->SetAccessor(String::NewSymbol("point"), PointGetter);
      
      Local<Function> constructor = s_constructorTemplate->GetFunction();


      exports->Set(String::NewSymbol("Geocoordinate"), constructor);
      return scope.Close(Undefined());
    }


    virtual ::Platform::Object^ GetObjectInstance() const override
    {
      return _instance;
    }

  private:
    
    Geocoordinate(::Windows::Devices::Geolocation::Geocoordinate^ instance)
    {
      _instance = instance;
    }
    
    
    static v8::Handle<v8::Value> New(const v8::Arguments& args)
    {
      HandleScope scope;
      
      ::Windows::Devices::Geolocation::Geocoordinate^ winRtInstance;


      if (args.Length() == 1 && OpaqueWrapper::IsOpaqueWrapper(args[0]) &&
        NodeRT::Utils::IsWinRtWrapperOf<::Windows::Devices::Geolocation::Geocoordinate^>(args[0]))
      {
        try 
        {
          winRtInstance = (::Windows::Devices::Geolocation::Geocoordinate^) NodeRT::Utils::GetObjectInstance(args[0]);
        }
        catch (Platform::Exception ^exception)
        {
          NodeRT::Utils::ThrowWinRtExceptionInJs(exception);
          return scope.Close(Undefined());
        }
      }
      else
      {
        ThrowException(Exception::Error(NodeRT::Utils::NewString(L"Invalid arguments, no suitable constructor found")));
        return scope.Close(Undefined());
      }

      args.This()->SetHiddenValue(String::NewSymbol("__winRtInstance__"), True());

      Geocoordinate *wrapperInstance = new Geocoordinate(winRtInstance);
      wrapperInstance->Wrap(args.This());

      return args.This();
    }


  



    static Handle<Value> AccuracyGetter(Local<String> property, const AccessorInfo &info)
    {
      HandleScope scope;
      
      if (!NodeRT::Utils::IsWinRtWrapperOf<::Windows::Devices::Geolocation::Geocoordinate^>(info.This()))
      {
        return scope.Close(Undefined());
      }

      Geocoordinate *wrapper = Geocoordinate::Unwrap<Geocoordinate>(info.This());

      try 
      {
        double result = wrapper->_instance->Accuracy;
        return scope.Close(Number::New(static_cast<double>(result)));
      }
      catch (Platform::Exception ^exception)
      {
        NodeRT::Utils::ThrowWinRtExceptionInJs(exception);
        return scope.Close(Undefined());
      }
    }
    
    static Handle<Value> AltitudeGetter(Local<String> property, const AccessorInfo &info)
    {
      HandleScope scope;
      
      if (!NodeRT::Utils::IsWinRtWrapperOf<::Windows::Devices::Geolocation::Geocoordinate^>(info.This()))
      {
        return scope.Close(Undefined());
      }

      Geocoordinate *wrapper = Geocoordinate::Unwrap<Geocoordinate>(info.This());

      try 
      {
        ::Platform::IBox<double>^ result = wrapper->_instance->Altitude;
        return scope.Close(result ? Number::New(static_cast<double>(result->Value)): static_cast<Handle<Value>>(Undefined()));
      }
      catch (Platform::Exception ^exception)
      {
        NodeRT::Utils::ThrowWinRtExceptionInJs(exception);
        return scope.Close(Undefined());
      }
    }
    
    static Handle<Value> AltitudeAccuracyGetter(Local<String> property, const AccessorInfo &info)
    {
      HandleScope scope;
      
      if (!NodeRT::Utils::IsWinRtWrapperOf<::Windows::Devices::Geolocation::Geocoordinate^>(info.This()))
      {
        return scope.Close(Undefined());
      }

      Geocoordinate *wrapper = Geocoordinate::Unwrap<Geocoordinate>(info.This());

      try 
      {
        ::Platform::IBox<double>^ result = wrapper->_instance->AltitudeAccuracy;
        return scope.Close(result ? Number::New(static_cast<double>(result->Value)): static_cast<Handle<Value>>(Undefined()));
      }
      catch (Platform::Exception ^exception)
      {
        NodeRT::Utils::ThrowWinRtExceptionInJs(exception);
        return scope.Close(Undefined());
      }
    }
    
    static Handle<Value> HeadingGetter(Local<String> property, const AccessorInfo &info)
    {
      HandleScope scope;
      
      if (!NodeRT::Utils::IsWinRtWrapperOf<::Windows::Devices::Geolocation::Geocoordinate^>(info.This()))
      {
        return scope.Close(Undefined());
      }

      Geocoordinate *wrapper = Geocoordinate::Unwrap<Geocoordinate>(info.This());

      try 
      {
        ::Platform::IBox<double>^ result = wrapper->_instance->Heading;
        return scope.Close(result ? Number::New(static_cast<double>(result->Value)): static_cast<Handle<Value>>(Undefined()));
      }
      catch (Platform::Exception ^exception)
      {
        NodeRT::Utils::ThrowWinRtExceptionInJs(exception);
        return scope.Close(Undefined());
      }
    }
    
    static Handle<Value> LatitudeGetter(Local<String> property, const AccessorInfo &info)
    {
      HandleScope scope;
      
      if (!NodeRT::Utils::IsWinRtWrapperOf<::Windows::Devices::Geolocation::Geocoordinate^>(info.This()))
      {
        return scope.Close(Undefined());
      }

      Geocoordinate *wrapper = Geocoordinate::Unwrap<Geocoordinate>(info.This());

      try 
      {
        double result = wrapper->_instance->Latitude;
        return scope.Close(Number::New(static_cast<double>(result)));
      }
      catch (Platform::Exception ^exception)
      {
        NodeRT::Utils::ThrowWinRtExceptionInJs(exception);
        return scope.Close(Undefined());
      }
    }
    
    static Handle<Value> LongitudeGetter(Local<String> property, const AccessorInfo &info)
    {
      HandleScope scope;
      
      if (!NodeRT::Utils::IsWinRtWrapperOf<::Windows::Devices::Geolocation::Geocoordinate^>(info.This()))
      {
        return scope.Close(Undefined());
      }

      Geocoordinate *wrapper = Geocoordinate::Unwrap<Geocoordinate>(info.This());

      try 
      {
        double result = wrapper->_instance->Longitude;
        return scope.Close(Number::New(static_cast<double>(result)));
      }
      catch (Platform::Exception ^exception)
      {
        NodeRT::Utils::ThrowWinRtExceptionInJs(exception);
        return scope.Close(Undefined());
      }
    }
    
    static Handle<Value> SpeedGetter(Local<String> property, const AccessorInfo &info)
    {
      HandleScope scope;
      
      if (!NodeRT::Utils::IsWinRtWrapperOf<::Windows::Devices::Geolocation::Geocoordinate^>(info.This()))
      {
        return scope.Close(Undefined());
      }

      Geocoordinate *wrapper = Geocoordinate::Unwrap<Geocoordinate>(info.This());

      try 
      {
        ::Platform::IBox<double>^ result = wrapper->_instance->Speed;
        return scope.Close(result ? Number::New(static_cast<double>(result->Value)): static_cast<Handle<Value>>(Undefined()));
      }
      catch (Platform::Exception ^exception)
      {
        NodeRT::Utils::ThrowWinRtExceptionInJs(exception);
        return scope.Close(Undefined());
      }
    }
    
    static Handle<Value> TimestampGetter(Local<String> property, const AccessorInfo &info)
    {
      HandleScope scope;
      
      if (!NodeRT::Utils::IsWinRtWrapperOf<::Windows::Devices::Geolocation::Geocoordinate^>(info.This()))
      {
        return scope.Close(Undefined());
      }

      Geocoordinate *wrapper = Geocoordinate::Unwrap<Geocoordinate>(info.This());

      try 
      {
        ::Windows::Foundation::DateTime result = wrapper->_instance->Timestamp;
        return scope.Close(Date::New(result.UniversalTime/10000.0 - 11644473600000));
      }
      catch (Platform::Exception ^exception)
      {
        NodeRT::Utils::ThrowWinRtExceptionInJs(exception);
        return scope.Close(Undefined());
      }
    }
    
    static Handle<Value> PositionSourceGetter(Local<String> property, const AccessorInfo &info)
    {
      HandleScope scope;
      
      if (!NodeRT::Utils::IsWinRtWrapperOf<::Windows::Devices::Geolocation::Geocoordinate^>(info.This()))
      {
        return scope.Close(Undefined());
      }

      Geocoordinate *wrapper = Geocoordinate::Unwrap<Geocoordinate>(info.This());

      try 
      {
        ::Windows::Devices::Geolocation::PositionSource result = wrapper->_instance->PositionSource;
        return scope.Close(Integer::New(static_cast<int>(result)));
      }
      catch (Platform::Exception ^exception)
      {
        NodeRT::Utils::ThrowWinRtExceptionInJs(exception);
        return scope.Close(Undefined());
      }
    }
    
    static Handle<Value> SatelliteDataGetter(Local<String> property, const AccessorInfo &info)
    {
      HandleScope scope;
      
      if (!NodeRT::Utils::IsWinRtWrapperOf<::Windows::Devices::Geolocation::Geocoordinate^>(info.This()))
      {
        return scope.Close(Undefined());
      }

      Geocoordinate *wrapper = Geocoordinate::Unwrap<Geocoordinate>(info.This());

      try 
      {
        ::Windows::Devices::Geolocation::GeocoordinateSatelliteData^ result = wrapper->_instance->SatelliteData;
        return scope.Close(WrapGeocoordinateSatelliteData(result));
      }
      catch (Platform::Exception ^exception)
      {
        NodeRT::Utils::ThrowWinRtExceptionInJs(exception);
        return scope.Close(Undefined());
      }
    }
    
    static Handle<Value> PointGetter(Local<String> property, const AccessorInfo &info)
    {
      HandleScope scope;
      
      if (!NodeRT::Utils::IsWinRtWrapperOf<::Windows::Devices::Geolocation::Geocoordinate^>(info.This()))
      {
        return scope.Close(Undefined());
      }

      Geocoordinate *wrapper = Geocoordinate::Unwrap<Geocoordinate>(info.This());

      try 
      {
        ::Windows::Devices::Geolocation::Geopoint^ result = wrapper->_instance->Point;
        return scope.Close(WrapGeopoint(result));
      }
      catch (Platform::Exception ^exception)
      {
        NodeRT::Utils::ThrowWinRtExceptionInJs(exception);
        return scope.Close(Undefined());
      }
    }
    


  private:
    ::Windows::Devices::Geolocation::Geocoordinate^ _instance;
    static Persistent<FunctionTemplate> s_constructorTemplate;

    friend v8::Handle<v8::Value> WrapGeocoordinate(::Windows::Devices::Geolocation::Geocoordinate^ wintRtInstance);
    friend ::Windows::Devices::Geolocation::Geocoordinate^ UnwrapGeocoordinate(Handle<Value> value);
    friend bool IsGeocoordinateWrapper(Handle<Value> value);
  };
  Persistent<FunctionTemplate> Geocoordinate::s_constructorTemplate;

  v8::Handle<v8::Value> WrapGeocoordinate(::Windows::Devices::Geolocation::Geocoordinate^ winRtInstance)
  {
    HandleScope scope;

    if (winRtInstance == nullptr)
    {
      return scope.Close(Undefined());
    }

    Handle<Object> opaqueWrapper = CreateOpaqueWrapper(winRtInstance);
    Handle<Value> args[] = {opaqueWrapper};
    return scope.Close(Geocoordinate::s_constructorTemplate->GetFunction()->NewInstance(_countof(args), args));
  }

  ::Windows::Devices::Geolocation::Geocoordinate^ UnwrapGeocoordinate(Handle<Value> value)
  {
     return Geocoordinate::Unwrap<Geocoordinate>(value.As<Object>())->_instance;
  }

  void InitGeocoordinate(Handle<Object> exports)
  {
    Geocoordinate::Init(exports);
  }

  class CivicAddress : public WrapperBase
  {
  public:    
    static v8::Handle<v8::Value> Init(const Handle<Object> exports)
    {
      HandleScope scope;
      
      s_constructorTemplate = Persistent<FunctionTemplate>::New(FunctionTemplate::New(New));
      s_constructorTemplate->SetClassName(String::NewSymbol("CivicAddress"));
      s_constructorTemplate->InstanceTemplate()->SetInternalFieldCount(1);
      
                              
      s_constructorTemplate->PrototypeTemplate()->SetAccessor(String::NewSymbol("city"), CityGetter);
      s_constructorTemplate->PrototypeTemplate()->SetAccessor(String::NewSymbol("country"), CountryGetter);
      s_constructorTemplate->PrototypeTemplate()->SetAccessor(String::NewSymbol("postalCode"), PostalCodeGetter);
      s_constructorTemplate->PrototypeTemplate()->SetAccessor(String::NewSymbol("state"), StateGetter);
      s_constructorTemplate->PrototypeTemplate()->SetAccessor(String::NewSymbol("timestamp"), TimestampGetter);
      
      Local<Function> constructor = s_constructorTemplate->GetFunction();


      exports->Set(String::NewSymbol("CivicAddress"), constructor);
      return scope.Close(Undefined());
    }


    virtual ::Platform::Object^ GetObjectInstance() const override
    {
      return _instance;
    }

  private:
    
    CivicAddress(::Windows::Devices::Geolocation::CivicAddress^ instance)
    {
      _instance = instance;
    }
    
    
    static v8::Handle<v8::Value> New(const v8::Arguments& args)
    {
      HandleScope scope;
      
      ::Windows::Devices::Geolocation::CivicAddress^ winRtInstance;


      if (args.Length() == 1 && OpaqueWrapper::IsOpaqueWrapper(args[0]) &&
        NodeRT::Utils::IsWinRtWrapperOf<::Windows::Devices::Geolocation::CivicAddress^>(args[0]))
      {
        try 
        {
          winRtInstance = (::Windows::Devices::Geolocation::CivicAddress^) NodeRT::Utils::GetObjectInstance(args[0]);
        }
        catch (Platform::Exception ^exception)
        {
          NodeRT::Utils::ThrowWinRtExceptionInJs(exception);
          return scope.Close(Undefined());
        }
      }
      else
      {
        ThrowException(Exception::Error(NodeRT::Utils::NewString(L"Invalid arguments, no suitable constructor found")));
        return scope.Close(Undefined());
      }

      args.This()->SetHiddenValue(String::NewSymbol("__winRtInstance__"), True());

      CivicAddress *wrapperInstance = new CivicAddress(winRtInstance);
      wrapperInstance->Wrap(args.This());

      return args.This();
    }


  



    static Handle<Value> CityGetter(Local<String> property, const AccessorInfo &info)
    {
      HandleScope scope;
      
      if (!NodeRT::Utils::IsWinRtWrapperOf<::Windows::Devices::Geolocation::CivicAddress^>(info.This()))
      {
        return scope.Close(Undefined());
      }

      CivicAddress *wrapper = CivicAddress::Unwrap<CivicAddress>(info.This());

      try 
      {
        Platform::String^ result = wrapper->_instance->City;
        return scope.Close(NodeRT::Utils::NewString(result->Data()));
      }
      catch (Platform::Exception ^exception)
      {
        NodeRT::Utils::ThrowWinRtExceptionInJs(exception);
        return scope.Close(Undefined());
      }
    }
    
    static Handle<Value> CountryGetter(Local<String> property, const AccessorInfo &info)
    {
      HandleScope scope;
      
      if (!NodeRT::Utils::IsWinRtWrapperOf<::Windows::Devices::Geolocation::CivicAddress^>(info.This()))
      {
        return scope.Close(Undefined());
      }

      CivicAddress *wrapper = CivicAddress::Unwrap<CivicAddress>(info.This());

      try 
      {
        Platform::String^ result = wrapper->_instance->Country;
        return scope.Close(NodeRT::Utils::NewString(result->Data()));
      }
      catch (Platform::Exception ^exception)
      {
        NodeRT::Utils::ThrowWinRtExceptionInJs(exception);
        return scope.Close(Undefined());
      }
    }
    
    static Handle<Value> PostalCodeGetter(Local<String> property, const AccessorInfo &info)
    {
      HandleScope scope;
      
      if (!NodeRT::Utils::IsWinRtWrapperOf<::Windows::Devices::Geolocation::CivicAddress^>(info.This()))
      {
        return scope.Close(Undefined());
      }

      CivicAddress *wrapper = CivicAddress::Unwrap<CivicAddress>(info.This());

      try 
      {
        Platform::String^ result = wrapper->_instance->PostalCode;
        return scope.Close(NodeRT::Utils::NewString(result->Data()));
      }
      catch (Platform::Exception ^exception)
      {
        NodeRT::Utils::ThrowWinRtExceptionInJs(exception);
        return scope.Close(Undefined());
      }
    }
    
    static Handle<Value> StateGetter(Local<String> property, const AccessorInfo &info)
    {
      HandleScope scope;
      
      if (!NodeRT::Utils::IsWinRtWrapperOf<::Windows::Devices::Geolocation::CivicAddress^>(info.This()))
      {
        return scope.Close(Undefined());
      }

      CivicAddress *wrapper = CivicAddress::Unwrap<CivicAddress>(info.This());

      try 
      {
        Platform::String^ result = wrapper->_instance->State;
        return scope.Close(NodeRT::Utils::NewString(result->Data()));
      }
      catch (Platform::Exception ^exception)
      {
        NodeRT::Utils::ThrowWinRtExceptionInJs(exception);
        return scope.Close(Undefined());
      }
    }
    
    static Handle<Value> TimestampGetter(Local<String> property, const AccessorInfo &info)
    {
      HandleScope scope;
      
      if (!NodeRT::Utils::IsWinRtWrapperOf<::Windows::Devices::Geolocation::CivicAddress^>(info.This()))
      {
        return scope.Close(Undefined());
      }

      CivicAddress *wrapper = CivicAddress::Unwrap<CivicAddress>(info.This());

      try 
      {
        ::Windows::Foundation::DateTime result = wrapper->_instance->Timestamp;
        return scope.Close(Date::New(result.UniversalTime/10000.0 - 11644473600000));
      }
      catch (Platform::Exception ^exception)
      {
        NodeRT::Utils::ThrowWinRtExceptionInJs(exception);
        return scope.Close(Undefined());
      }
    }
    


  private:
    ::Windows::Devices::Geolocation::CivicAddress^ _instance;
    static Persistent<FunctionTemplate> s_constructorTemplate;

    friend v8::Handle<v8::Value> WrapCivicAddress(::Windows::Devices::Geolocation::CivicAddress^ wintRtInstance);
    friend ::Windows::Devices::Geolocation::CivicAddress^ UnwrapCivicAddress(Handle<Value> value);
    friend bool IsCivicAddressWrapper(Handle<Value> value);
  };
  Persistent<FunctionTemplate> CivicAddress::s_constructorTemplate;

  v8::Handle<v8::Value> WrapCivicAddress(::Windows::Devices::Geolocation::CivicAddress^ winRtInstance)
  {
    HandleScope scope;

    if (winRtInstance == nullptr)
    {
      return scope.Close(Undefined());
    }

    Handle<Object> opaqueWrapper = CreateOpaqueWrapper(winRtInstance);
    Handle<Value> args[] = {opaqueWrapper};
    return scope.Close(CivicAddress::s_constructorTemplate->GetFunction()->NewInstance(_countof(args), args));
  }

  ::Windows::Devices::Geolocation::CivicAddress^ UnwrapCivicAddress(Handle<Value> value)
  {
     return CivicAddress::Unwrap<CivicAddress>(value.As<Object>())->_instance;
  }

  void InitCivicAddress(Handle<Object> exports)
  {
    CivicAddress::Init(exports);
  }

  class Geoposition : public WrapperBase
  {
  public:    
    static v8::Handle<v8::Value> Init(const Handle<Object> exports)
    {
      HandleScope scope;
      
      s_constructorTemplate = Persistent<FunctionTemplate>::New(FunctionTemplate::New(New));
      s_constructorTemplate->SetClassName(String::NewSymbol("Geoposition"));
      s_constructorTemplate->InstanceTemplate()->SetInternalFieldCount(1);
      
                              
      s_constructorTemplate->PrototypeTemplate()->SetAccessor(String::NewSymbol("civicAddress"), CivicAddressGetter);
      s_constructorTemplate->PrototypeTemplate()->SetAccessor(String::NewSymbol("coordinate"), CoordinateGetter);
      
      Local<Function> constructor = s_constructorTemplate->GetFunction();


      exports->Set(String::NewSymbol("Geoposition"), constructor);
      return scope.Close(Undefined());
    }


    virtual ::Platform::Object^ GetObjectInstance() const override
    {
      return _instance;
    }

  private:
    
    Geoposition(::Windows::Devices::Geolocation::Geoposition^ instance)
    {
      _instance = instance;
    }
    
    
    static v8::Handle<v8::Value> New(const v8::Arguments& args)
    {
      HandleScope scope;
      
      ::Windows::Devices::Geolocation::Geoposition^ winRtInstance;


      if (args.Length() == 1 && OpaqueWrapper::IsOpaqueWrapper(args[0]) &&
        NodeRT::Utils::IsWinRtWrapperOf<::Windows::Devices::Geolocation::Geoposition^>(args[0]))
      {
        try 
        {
          winRtInstance = (::Windows::Devices::Geolocation::Geoposition^) NodeRT::Utils::GetObjectInstance(args[0]);
        }
        catch (Platform::Exception ^exception)
        {
          NodeRT::Utils::ThrowWinRtExceptionInJs(exception);
          return scope.Close(Undefined());
        }
      }
      else
      {
        ThrowException(Exception::Error(NodeRT::Utils::NewString(L"Invalid arguments, no suitable constructor found")));
        return scope.Close(Undefined());
      }

      args.This()->SetHiddenValue(String::NewSymbol("__winRtInstance__"), True());

      Geoposition *wrapperInstance = new Geoposition(winRtInstance);
      wrapperInstance->Wrap(args.This());

      return args.This();
    }


  



    static Handle<Value> CivicAddressGetter(Local<String> property, const AccessorInfo &info)
    {
      HandleScope scope;
      
      if (!NodeRT::Utils::IsWinRtWrapperOf<::Windows::Devices::Geolocation::Geoposition^>(info.This()))
      {
        return scope.Close(Undefined());
      }

      Geoposition *wrapper = Geoposition::Unwrap<Geoposition>(info.This());

      try 
      {
        ::Windows::Devices::Geolocation::CivicAddress^ result = wrapper->_instance->CivicAddress;
        return scope.Close(WrapCivicAddress(result));
      }
      catch (Platform::Exception ^exception)
      {
        NodeRT::Utils::ThrowWinRtExceptionInJs(exception);
        return scope.Close(Undefined());
      }
    }
    
    static Handle<Value> CoordinateGetter(Local<String> property, const AccessorInfo &info)
    {
      HandleScope scope;
      
      if (!NodeRT::Utils::IsWinRtWrapperOf<::Windows::Devices::Geolocation::Geoposition^>(info.This()))
      {
        return scope.Close(Undefined());
      }

      Geoposition *wrapper = Geoposition::Unwrap<Geoposition>(info.This());

      try 
      {
        ::Windows::Devices::Geolocation::Geocoordinate^ result = wrapper->_instance->Coordinate;
        return scope.Close(WrapGeocoordinate(result));
      }
      catch (Platform::Exception ^exception)
      {
        NodeRT::Utils::ThrowWinRtExceptionInJs(exception);
        return scope.Close(Undefined());
      }
    }
    


  private:
    ::Windows::Devices::Geolocation::Geoposition^ _instance;
    static Persistent<FunctionTemplate> s_constructorTemplate;

    friend v8::Handle<v8::Value> WrapGeoposition(::Windows::Devices::Geolocation::Geoposition^ wintRtInstance);
    friend ::Windows::Devices::Geolocation::Geoposition^ UnwrapGeoposition(Handle<Value> value);
    friend bool IsGeopositionWrapper(Handle<Value> value);
  };
  Persistent<FunctionTemplate> Geoposition::s_constructorTemplate;

  v8::Handle<v8::Value> WrapGeoposition(::Windows::Devices::Geolocation::Geoposition^ winRtInstance)
  {
    HandleScope scope;

    if (winRtInstance == nullptr)
    {
      return scope.Close(Undefined());
    }

    Handle<Object> opaqueWrapper = CreateOpaqueWrapper(winRtInstance);
    Handle<Value> args[] = {opaqueWrapper};
    return scope.Close(Geoposition::s_constructorTemplate->GetFunction()->NewInstance(_countof(args), args));
  }

  ::Windows::Devices::Geolocation::Geoposition^ UnwrapGeoposition(Handle<Value> value)
  {
     return Geoposition::Unwrap<Geoposition>(value.As<Object>())->_instance;
  }

  void InitGeoposition(Handle<Object> exports)
  {
    Geoposition::Init(exports);
  }

  class PositionChangedEventArgs : public WrapperBase
  {
  public:    
    static v8::Handle<v8::Value> Init(const Handle<Object> exports)
    {
      HandleScope scope;
      
      s_constructorTemplate = Persistent<FunctionTemplate>::New(FunctionTemplate::New(New));
      s_constructorTemplate->SetClassName(String::NewSymbol("PositionChangedEventArgs"));
      s_constructorTemplate->InstanceTemplate()->SetInternalFieldCount(1);
      
                              
      s_constructorTemplate->PrototypeTemplate()->SetAccessor(String::NewSymbol("position"), PositionGetter);
      
      Local<Function> constructor = s_constructorTemplate->GetFunction();


      exports->Set(String::NewSymbol("PositionChangedEventArgs"), constructor);
      return scope.Close(Undefined());
    }


    virtual ::Platform::Object^ GetObjectInstance() const override
    {
      return _instance;
    }

  private:
    
    PositionChangedEventArgs(::Windows::Devices::Geolocation::PositionChangedEventArgs^ instance)
    {
      _instance = instance;
    }
    
    
    static v8::Handle<v8::Value> New(const v8::Arguments& args)
    {
      HandleScope scope;
      
      ::Windows::Devices::Geolocation::PositionChangedEventArgs^ winRtInstance;


      if (args.Length() == 1 && OpaqueWrapper::IsOpaqueWrapper(args[0]) &&
        NodeRT::Utils::IsWinRtWrapperOf<::Windows::Devices::Geolocation::PositionChangedEventArgs^>(args[0]))
      {
        try 
        {
          winRtInstance = (::Windows::Devices::Geolocation::PositionChangedEventArgs^) NodeRT::Utils::GetObjectInstance(args[0]);
        }
        catch (Platform::Exception ^exception)
        {
          NodeRT::Utils::ThrowWinRtExceptionInJs(exception);
          return scope.Close(Undefined());
        }
      }
      else
      {
        ThrowException(Exception::Error(NodeRT::Utils::NewString(L"Invalid arguments, no suitable constructor found")));
        return scope.Close(Undefined());
      }

      args.This()->SetHiddenValue(String::NewSymbol("__winRtInstance__"), True());

      PositionChangedEventArgs *wrapperInstance = new PositionChangedEventArgs(winRtInstance);
      wrapperInstance->Wrap(args.This());

      return args.This();
    }


  



    static Handle<Value> PositionGetter(Local<String> property, const AccessorInfo &info)
    {
      HandleScope scope;
      
      if (!NodeRT::Utils::IsWinRtWrapperOf<::Windows::Devices::Geolocation::PositionChangedEventArgs^>(info.This()))
      {
        return scope.Close(Undefined());
      }

      PositionChangedEventArgs *wrapper = PositionChangedEventArgs::Unwrap<PositionChangedEventArgs>(info.This());

      try 
      {
        ::Windows::Devices::Geolocation::Geoposition^ result = wrapper->_instance->Position;
        return scope.Close(WrapGeoposition(result));
      }
      catch (Platform::Exception ^exception)
      {
        NodeRT::Utils::ThrowWinRtExceptionInJs(exception);
        return scope.Close(Undefined());
      }
    }
    


  private:
    ::Windows::Devices::Geolocation::PositionChangedEventArgs^ _instance;
    static Persistent<FunctionTemplate> s_constructorTemplate;

    friend v8::Handle<v8::Value> WrapPositionChangedEventArgs(::Windows::Devices::Geolocation::PositionChangedEventArgs^ wintRtInstance);
    friend ::Windows::Devices::Geolocation::PositionChangedEventArgs^ UnwrapPositionChangedEventArgs(Handle<Value> value);
    friend bool IsPositionChangedEventArgsWrapper(Handle<Value> value);
  };
  Persistent<FunctionTemplate> PositionChangedEventArgs::s_constructorTemplate;

  v8::Handle<v8::Value> WrapPositionChangedEventArgs(::Windows::Devices::Geolocation::PositionChangedEventArgs^ winRtInstance)
  {
    HandleScope scope;

    if (winRtInstance == nullptr)
    {
      return scope.Close(Undefined());
    }

    Handle<Object> opaqueWrapper = CreateOpaqueWrapper(winRtInstance);
    Handle<Value> args[] = {opaqueWrapper};
    return scope.Close(PositionChangedEventArgs::s_constructorTemplate->GetFunction()->NewInstance(_countof(args), args));
  }

  ::Windows::Devices::Geolocation::PositionChangedEventArgs^ UnwrapPositionChangedEventArgs(Handle<Value> value)
  {
     return PositionChangedEventArgs::Unwrap<PositionChangedEventArgs>(value.As<Object>())->_instance;
  }

  void InitPositionChangedEventArgs(Handle<Object> exports)
  {
    PositionChangedEventArgs::Init(exports);
  }

  class StatusChangedEventArgs : public WrapperBase
  {
  public:    
    static v8::Handle<v8::Value> Init(const Handle<Object> exports)
    {
      HandleScope scope;
      
      s_constructorTemplate = Persistent<FunctionTemplate>::New(FunctionTemplate::New(New));
      s_constructorTemplate->SetClassName(String::NewSymbol("StatusChangedEventArgs"));
      s_constructorTemplate->InstanceTemplate()->SetInternalFieldCount(1);
      
                              
      s_constructorTemplate->PrototypeTemplate()->SetAccessor(String::NewSymbol("status"), StatusGetter);
      
      Local<Function> constructor = s_constructorTemplate->GetFunction();


      exports->Set(String::NewSymbol("StatusChangedEventArgs"), constructor);
      return scope.Close(Undefined());
    }


    virtual ::Platform::Object^ GetObjectInstance() const override
    {
      return _instance;
    }

  private:
    
    StatusChangedEventArgs(::Windows::Devices::Geolocation::StatusChangedEventArgs^ instance)
    {
      _instance = instance;
    }
    
    
    static v8::Handle<v8::Value> New(const v8::Arguments& args)
    {
      HandleScope scope;
      
      ::Windows::Devices::Geolocation::StatusChangedEventArgs^ winRtInstance;


      if (args.Length() == 1 && OpaqueWrapper::IsOpaqueWrapper(args[0]) &&
        NodeRT::Utils::IsWinRtWrapperOf<::Windows::Devices::Geolocation::StatusChangedEventArgs^>(args[0]))
      {
        try 
        {
          winRtInstance = (::Windows::Devices::Geolocation::StatusChangedEventArgs^) NodeRT::Utils::GetObjectInstance(args[0]);
        }
        catch (Platform::Exception ^exception)
        {
          NodeRT::Utils::ThrowWinRtExceptionInJs(exception);
          return scope.Close(Undefined());
        }
      }
      else
      {
        ThrowException(Exception::Error(NodeRT::Utils::NewString(L"Invalid arguments, no suitable constructor found")));
        return scope.Close(Undefined());
      }

      args.This()->SetHiddenValue(String::NewSymbol("__winRtInstance__"), True());

      StatusChangedEventArgs *wrapperInstance = new StatusChangedEventArgs(winRtInstance);
      wrapperInstance->Wrap(args.This());

      return args.This();
    }


  



    static Handle<Value> StatusGetter(Local<String> property, const AccessorInfo &info)
    {
      HandleScope scope;
      
      if (!NodeRT::Utils::IsWinRtWrapperOf<::Windows::Devices::Geolocation::StatusChangedEventArgs^>(info.This()))
      {
        return scope.Close(Undefined());
      }

      StatusChangedEventArgs *wrapper = StatusChangedEventArgs::Unwrap<StatusChangedEventArgs>(info.This());

      try 
      {
        ::Windows::Devices::Geolocation::PositionStatus result = wrapper->_instance->Status;
        return scope.Close(Integer::New(static_cast<int>(result)));
      }
      catch (Platform::Exception ^exception)
      {
        NodeRT::Utils::ThrowWinRtExceptionInJs(exception);
        return scope.Close(Undefined());
      }
    }
    


  private:
    ::Windows::Devices::Geolocation::StatusChangedEventArgs^ _instance;
    static Persistent<FunctionTemplate> s_constructorTemplate;

    friend v8::Handle<v8::Value> WrapStatusChangedEventArgs(::Windows::Devices::Geolocation::StatusChangedEventArgs^ wintRtInstance);
    friend ::Windows::Devices::Geolocation::StatusChangedEventArgs^ UnwrapStatusChangedEventArgs(Handle<Value> value);
    friend bool IsStatusChangedEventArgsWrapper(Handle<Value> value);
  };
  Persistent<FunctionTemplate> StatusChangedEventArgs::s_constructorTemplate;

  v8::Handle<v8::Value> WrapStatusChangedEventArgs(::Windows::Devices::Geolocation::StatusChangedEventArgs^ winRtInstance)
  {
    HandleScope scope;

    if (winRtInstance == nullptr)
    {
      return scope.Close(Undefined());
    }

    Handle<Object> opaqueWrapper = CreateOpaqueWrapper(winRtInstance);
    Handle<Value> args[] = {opaqueWrapper};
    return scope.Close(StatusChangedEventArgs::s_constructorTemplate->GetFunction()->NewInstance(_countof(args), args));
  }

  ::Windows::Devices::Geolocation::StatusChangedEventArgs^ UnwrapStatusChangedEventArgs(Handle<Value> value)
  {
     return StatusChangedEventArgs::Unwrap<StatusChangedEventArgs>(value.As<Object>())->_instance;
  }

  void InitStatusChangedEventArgs(Handle<Object> exports)
  {
    StatusChangedEventArgs::Init(exports);
  }

  class Geolocator : public WrapperBase
  {
  public:    
    static v8::Handle<v8::Value> Init(const Handle<Object> exports)
    {
      HandleScope scope;
      
      s_constructorTemplate = Persistent<FunctionTemplate>::New(FunctionTemplate::New(New));
      s_constructorTemplate->SetClassName(String::NewSymbol("Geolocator"));
      s_constructorTemplate->InstanceTemplate()->SetInternalFieldCount(1);
      
      Handle<Value> asyncSymbol = String::NewSymbol("__winRtAsync__");
      Handle<Function> func;
                  
      func = FunctionTemplate::New(GetGeopositionAsync)->GetFunction();
      func->Set(asyncSymbol, True(), PropertyAttribute::DontEnum);
      s_constructorTemplate->PrototypeTemplate()->Set(String::NewSymbol("getGeopositionAsync"), func);
      
            
      Local<Function> addListenerFunc = FunctionTemplate::New(AddListener)->GetFunction();
      s_constructorTemplate->PrototypeTemplate()->Set(String::NewSymbol("addListener"), addListenerFunc);
      s_constructorTemplate->PrototypeTemplate()->Set(String::NewSymbol("on"), addListenerFunc);
      Local<Function> removeListenerFunc = FunctionTemplate::New(RemoveListener)->GetFunction();
      s_constructorTemplate->PrototypeTemplate()->Set(String::NewSymbol("removeListener"), removeListenerFunc);
      s_constructorTemplate->PrototypeTemplate()->Set(String::NewSymbol("off"), removeListenerFunc);
            
      s_constructorTemplate->PrototypeTemplate()->SetAccessor(String::NewSymbol("reportInterval"), ReportIntervalGetter, ReportIntervalSetter);
      s_constructorTemplate->PrototypeTemplate()->SetAccessor(String::NewSymbol("movementThreshold"), MovementThresholdGetter, MovementThresholdSetter);
      s_constructorTemplate->PrototypeTemplate()->SetAccessor(String::NewSymbol("desiredAccuracy"), DesiredAccuracyGetter, DesiredAccuracySetter);
      s_constructorTemplate->PrototypeTemplate()->SetAccessor(String::NewSymbol("locationStatus"), LocationStatusGetter);
      s_constructorTemplate->PrototypeTemplate()->SetAccessor(String::NewSymbol("desiredAccuracyInMeters"), DesiredAccuracyInMetersGetter, DesiredAccuracyInMetersSetter);
      
      Local<Function> constructor = s_constructorTemplate->GetFunction();


      exports->Set(String::NewSymbol("Geolocator"), constructor);
      return scope.Close(Undefined());
    }


    virtual ::Platform::Object^ GetObjectInstance() const override
    {
      return _instance;
    }

  private:
    
    Geolocator(::Windows::Devices::Geolocation::Geolocator^ instance)
    {
      _instance = instance;
    }
    
    
    static v8::Handle<v8::Value> New(const v8::Arguments& args)
    {
      HandleScope scope;
      
      ::Windows::Devices::Geolocation::Geolocator^ winRtInstance;


      if (args.Length() == 1 && OpaqueWrapper::IsOpaqueWrapper(args[0]) &&
        NodeRT::Utils::IsWinRtWrapperOf<::Windows::Devices::Geolocation::Geolocator^>(args[0]))
      {
        try 
        {
          winRtInstance = (::Windows::Devices::Geolocation::Geolocator^) NodeRT::Utils::GetObjectInstance(args[0]);
        }
        catch (Platform::Exception ^exception)
        {
          NodeRT::Utils::ThrowWinRtExceptionInJs(exception);
          return scope.Close(Undefined());
        }
      }
      else if (args.Length() == 0)
      {
        try
        {
          winRtInstance = ref new ::Windows::Devices::Geolocation::Geolocator();
        }
        catch (Platform::Exception ^exception)
        {
          NodeRT::Utils::ThrowWinRtExceptionInJs(exception);
          return scope.Close(Undefined());
        }
      }
      else
      {
        ThrowException(Exception::Error(NodeRT::Utils::NewString(L"Invalid arguments, no suitable constructor found")));
        return scope.Close(Undefined());
      }

      args.This()->SetHiddenValue(String::NewSymbol("__winRtInstance__"), True());

      Geolocator *wrapperInstance = new Geolocator(winRtInstance);
      wrapperInstance->Wrap(args.This());

      return args.This();
    }


    static Handle<Value> GetGeopositionAsync(const v8::Arguments& args)
    {
      HandleScope scope;

      if (!NodeRT::Utils::IsWinRtWrapperOf<::Windows::Devices::Geolocation::Geolocator^>(args.This()))
      {
        return scope.Close(Undefined());
      }

      if (args.Length() == 0 || !args[args.Length() -1]->IsFunction())
      {
          ThrowException(Exception::Error(NodeRT::Utils::NewString(L"Bad arguments: No callback was given")));
          return scope.Close(Undefined());
      }

      Geolocator *wrapper = Geolocator::Unwrap<Geolocator>(args.This());

      ::Windows::Foundation::IAsyncOperation<::Windows::Devices::Geolocation::Geoposition^>^ op;
    

      if (args.Length() == 1)
      {
        try
        {
          op = wrapper->_instance->GetGeopositionAsync();
        }
        catch (Platform::Exception ^exception)
        {
          NodeRT::Utils::ThrowWinRtExceptionInJs(exception);
          return scope.Close(Undefined());
        }
      }
      else if (args.Length() == 3
        && args[0]->IsNumber()
        && args[1]->IsNumber())
      {
        try
        {
          ::Windows::Foundation::TimeSpan arg0 = NodeRT::Utils::TimeSpanFromMilli(static_cast<int64_t>(args[0]->NumberValue()));
          ::Windows::Foundation::TimeSpan arg1 = NodeRT::Utils::TimeSpanFromMilli(static_cast<int64_t>(args[1]->NumberValue()));
          
          op = wrapper->_instance->GetGeopositionAsync(arg0,arg1);
        }
        catch (Platform::Exception ^exception)
        {
          NodeRT::Utils::ThrowWinRtExceptionInJs(exception);
          return scope.Close(Undefined());
        }
      }
      else 
      {
        ThrowException(Exception::Error(NodeRT::Utils::NewString(L"Bad arguments: no suitable overload found")));
        return scope.Close(Undefined());
      }
    
      auto opTask = create_task(op);
      uv_async_t* asyncToken = NodeUtils::Async::GetAsyncToken(args[args.Length() -1].As<Function>());

      opTask.then( [asyncToken] (task<::Windows::Devices::Geolocation::Geoposition^> t) 
      {	
        try
        {
          auto result = t.get();
          NodeUtils::Async::RunCallbackOnMain(asyncToken, [result](NodeUtils::InvokeCallbackDelegate invokeCallback) {


            TryCatch tryCatch;
            Handle<Value> error; 
            Handle<Value> arg1 = WrapGeoposition(result);
            if (tryCatch.HasCaught())
            {
              error = tryCatch.Exception()->ToObject();
            }
            else 
            {
              error = Undefined();
            }
            if (arg1.IsEmpty()) arg1 = Undefined();
            Handle<Value> args[] = {error, arg1};

            invokeCallback(_countof(args), args);
          });
        }
        catch (Platform::Exception^ exception)
        {
          NodeUtils::Async::RunCallbackOnMain(asyncToken, [exception](NodeUtils::InvokeCallbackDelegate invokeCallback) {
             
            Handle<Value> error = NodeRT::Utils::WinRtExceptionToJsError(exception);
        
            Handle<Value> args[] = {error};
            invokeCallback(_countof(args), args);
          });
        }  		
      });

      return scope.Close(Undefined());
    }
  



    static Handle<Value> ReportIntervalGetter(Local<String> property, const AccessorInfo &info)
    {
      HandleScope scope;
      
      if (!NodeRT::Utils::IsWinRtWrapperOf<::Windows::Devices::Geolocation::Geolocator^>(info.This()))
      {
        return scope.Close(Undefined());
      }

      Geolocator *wrapper = Geolocator::Unwrap<Geolocator>(info.This());

      try 
      {
        unsigned int result = wrapper->_instance->ReportInterval;
        return scope.Close(Integer::New(result));
      }
      catch (Platform::Exception ^exception)
      {
        NodeRT::Utils::ThrowWinRtExceptionInJs(exception);
        return scope.Close(Undefined());
      }
    }
    
    static void ReportIntervalSetter(Local<String> property, Local<Value> value, const AccessorInfo &info)
    {
      HandleScope scope;
      
      if (!value->IsUint32())
      {
        ThrowException(Exception::Error(NodeRT::Utils::NewString(L"Value to set is of unexpected type")));
        return;
      }

      if (!NodeRT::Utils::IsWinRtWrapperOf<::Windows::Devices::Geolocation::Geolocator^>(info.This()))
      {
        return;
      }

      Geolocator *wrapper = Geolocator::Unwrap<Geolocator>(info.This());

      try 
      {
        
        unsigned int winRtValue = static_cast<unsigned int>(value->IntegerValue());

        wrapper->_instance->ReportInterval = winRtValue;
      }
      catch (Platform::Exception ^exception)
      {
        NodeRT::Utils::ThrowWinRtExceptionInJs(exception);
      }
    }
    
    static Handle<Value> MovementThresholdGetter(Local<String> property, const AccessorInfo &info)
    {
      HandleScope scope;
      
      if (!NodeRT::Utils::IsWinRtWrapperOf<::Windows::Devices::Geolocation::Geolocator^>(info.This()))
      {
        return scope.Close(Undefined());
      }

      Geolocator *wrapper = Geolocator::Unwrap<Geolocator>(info.This());

      try 
      {
        double result = wrapper->_instance->MovementThreshold;
        return scope.Close(Number::New(static_cast<double>(result)));
      }
      catch (Platform::Exception ^exception)
      {
        NodeRT::Utils::ThrowWinRtExceptionInJs(exception);
        return scope.Close(Undefined());
      }
    }
    
    static void MovementThresholdSetter(Local<String> property, Local<Value> value, const AccessorInfo &info)
    {
      HandleScope scope;
      
      if (!value->IsNumber())
      {
        ThrowException(Exception::Error(NodeRT::Utils::NewString(L"Value to set is of unexpected type")));
        return;
      }

      if (!NodeRT::Utils::IsWinRtWrapperOf<::Windows::Devices::Geolocation::Geolocator^>(info.This()))
      {
        return;
      }

      Geolocator *wrapper = Geolocator::Unwrap<Geolocator>(info.This());

      try 
      {
        
        double winRtValue = value->NumberValue();

        wrapper->_instance->MovementThreshold = winRtValue;
      }
      catch (Platform::Exception ^exception)
      {
        NodeRT::Utils::ThrowWinRtExceptionInJs(exception);
      }
    }
    
    static Handle<Value> DesiredAccuracyGetter(Local<String> property, const AccessorInfo &info)
    {
      HandleScope scope;
      
      if (!NodeRT::Utils::IsWinRtWrapperOf<::Windows::Devices::Geolocation::Geolocator^>(info.This()))
      {
        return scope.Close(Undefined());
      }

      Geolocator *wrapper = Geolocator::Unwrap<Geolocator>(info.This());

      try 
      {
        ::Windows::Devices::Geolocation::PositionAccuracy result = wrapper->_instance->DesiredAccuracy;
        return scope.Close(Integer::New(static_cast<int>(result)));
      }
      catch (Platform::Exception ^exception)
      {
        NodeRT::Utils::ThrowWinRtExceptionInJs(exception);
        return scope.Close(Undefined());
      }
    }
    
    static void DesiredAccuracySetter(Local<String> property, Local<Value> value, const AccessorInfo &info)
    {
      HandleScope scope;
      
      if (!value->IsInt32())
      {
        ThrowException(Exception::Error(NodeRT::Utils::NewString(L"Value to set is of unexpected type")));
        return;
      }

      if (!NodeRT::Utils::IsWinRtWrapperOf<::Windows::Devices::Geolocation::Geolocator^>(info.This()))
      {
        return;
      }

      Geolocator *wrapper = Geolocator::Unwrap<Geolocator>(info.This());

      try 
      {
        
        ::Windows::Devices::Geolocation::PositionAccuracy winRtValue = static_cast<::Windows::Devices::Geolocation::PositionAccuracy>(value->Int32Value());

        wrapper->_instance->DesiredAccuracy = winRtValue;
      }
      catch (Platform::Exception ^exception)
      {
        NodeRT::Utils::ThrowWinRtExceptionInJs(exception);
      }
    }
    
    static Handle<Value> LocationStatusGetter(Local<String> property, const AccessorInfo &info)
    {
      HandleScope scope;
      
      if (!NodeRT::Utils::IsWinRtWrapperOf<::Windows::Devices::Geolocation::Geolocator^>(info.This()))
      {
        return scope.Close(Undefined());
      }

      Geolocator *wrapper = Geolocator::Unwrap<Geolocator>(info.This());

      try 
      {
        ::Windows::Devices::Geolocation::PositionStatus result = wrapper->_instance->LocationStatus;
        return scope.Close(Integer::New(static_cast<int>(result)));
      }
      catch (Platform::Exception ^exception)
      {
        NodeRT::Utils::ThrowWinRtExceptionInJs(exception);
        return scope.Close(Undefined());
      }
    }
    
    static Handle<Value> DesiredAccuracyInMetersGetter(Local<String> property, const AccessorInfo &info)
    {
      HandleScope scope;
      
      if (!NodeRT::Utils::IsWinRtWrapperOf<::Windows::Devices::Geolocation::Geolocator^>(info.This()))
      {
        return scope.Close(Undefined());
      }

      Geolocator *wrapper = Geolocator::Unwrap<Geolocator>(info.This());

      try 
      {
        ::Platform::IBox<unsigned int>^ result = wrapper->_instance->DesiredAccuracyInMeters;
        return scope.Close(result ? Integer::New(result->Value): static_cast<Handle<Value>>(Undefined()));
      }
      catch (Platform::Exception ^exception)
      {
        NodeRT::Utils::ThrowWinRtExceptionInJs(exception);
        return scope.Close(Undefined());
      }
    }
    
    static void DesiredAccuracyInMetersSetter(Local<String> property, Local<Value> value, const AccessorInfo &info)
    {
      HandleScope scope;
      
      if (!value->IsUint32())
      {
        ThrowException(Exception::Error(NodeRT::Utils::NewString(L"Value to set is of unexpected type")));
        return;
      }

      if (!NodeRT::Utils::IsWinRtWrapperOf<::Windows::Devices::Geolocation::Geolocator^>(info.This()))
      {
        return;
      }

      Geolocator *wrapper = Geolocator::Unwrap<Geolocator>(info.This());

      try 
      {
        
        ::Platform::IBox<unsigned int>^ winRtValue = ref new ::Platform::Box<unsigned int>(static_cast<unsigned int>(value->IntegerValue()));

        wrapper->_instance->DesiredAccuracyInMeters = winRtValue;
      }
      catch (Platform::Exception ^exception)
      {
        NodeRT::Utils::ThrowWinRtExceptionInJs(exception);
      }
    }
    


    static v8::Handle<v8::Value> AddListener(const v8::Arguments& args)
    {
      HandleScope scope;

      if (args.Length() < 2 || !args[0]->IsString() || !args[1]->IsFunction())
      {
        ThrowException(Exception::Error(NodeRT::Utils::NewString(L"wrong arguments, expected arguments are eventName(string),callback(function)")));
        return scope.Close(Undefined());
      }

      String::Value eventName(args[0]);
      auto str = *eventName;
      
      Local<Function> callback = args[1].As<Function>();
      
      ::Windows::Foundation::EventRegistrationToken registrationToken;
      if (NodeRT::Utils::CaseInsenstiveEquals(L"positionChanged", str))
      {
        if (!NodeRT::Utils::IsWinRtWrapperOf<::Windows::Devices::Geolocation::Geolocator^>(args.This()))
        {
          ThrowException(Exception::Error(NodeRT::Utils::NewString(L"The caller of this method isn't of the expected type or internal WinRt object was disposed")));
          return scope.Close(Undefined());
        }
        Geolocator *wrapper = Geolocator::Unwrap<Geolocator>(args.This());
      
        try
        {
          std::shared_ptr<Persistent<Object>> callbackObjPtr(new Persistent<Object>(Persistent<Object>::New(NodeRT::Utils::CreateCallbackObjectInDomain(callback))), 
            [] (Persistent<Object> *ptr ) {
              NodeUtils::Async::RunOnMain([ptr]() {
                ptr->Dispose();
                delete ptr;
            });
          });

          registrationToken = wrapper->_instance->PositionChanged::add(
            ref new ::Windows::Foundation::TypedEventHandler<::Windows::Devices::Geolocation::Geolocator^, ::Windows::Devices::Geolocation::PositionChangedEventArgs^>(
            [callbackObjPtr](::Windows::Devices::Geolocation::Geolocator^ arg0, ::Windows::Devices::Geolocation::PositionChangedEventArgs^ arg1) {
              NodeUtils::Async::RunOnMain([callbackObjPtr , arg0, arg1]() {
                TryCatch tryCatch;
              
                Handle<Value> error;

                Handle<Value> wrappedArg0 = WrapGeolocator(arg0);
                Handle<Value> wrappedArg1 = WrapPositionChangedEventArgs(arg1);

                if (tryCatch.HasCaught())
                {
                  error = tryCatch.Exception()->ToObject();
                }
                else 
                {
                  error = Undefined();
                }


                if (wrappedArg0.IsEmpty()) wrappedArg0 = Undefined();
                if (wrappedArg1.IsEmpty()) wrappedArg1 = Undefined();

                Handle<Value> args[] = { wrappedArg0, wrappedArg1 };
                NodeRT::Utils::CallCallbackInDomain(*callbackObjPtr, _countof(args), args);
              });
            })
          );
        }
        catch (Platform::Exception ^exception)
        {
          NodeRT::Utils::ThrowWinRtExceptionInJs(exception);
          return scope.Close(Undefined());
        }

      }
      else if (NodeRT::Utils::CaseInsenstiveEquals(L"statusChanged", str))
      {
        if (!NodeRT::Utils::IsWinRtWrapperOf<::Windows::Devices::Geolocation::Geolocator^>(args.This()))
        {
          ThrowException(Exception::Error(NodeRT::Utils::NewString(L"The caller of this method isn't of the expected type or internal WinRt object was disposed")));
          return scope.Close(Undefined());
        }
        Geolocator *wrapper = Geolocator::Unwrap<Geolocator>(args.This());
      
        try
        {
          std::shared_ptr<Persistent<Object>> callbackObjPtr(new Persistent<Object>(Persistent<Object>::New(NodeRT::Utils::CreateCallbackObjectInDomain(callback))), 
            [] (Persistent<Object> *ptr ) {
              NodeUtils::Async::RunOnMain([ptr]() {
                ptr->Dispose();
                delete ptr;
            });
          });

          registrationToken = wrapper->_instance->StatusChanged::add(
            ref new ::Windows::Foundation::TypedEventHandler<::Windows::Devices::Geolocation::Geolocator^, ::Windows::Devices::Geolocation::StatusChangedEventArgs^>(
            [callbackObjPtr](::Windows::Devices::Geolocation::Geolocator^ arg0, ::Windows::Devices::Geolocation::StatusChangedEventArgs^ arg1) {
              NodeUtils::Async::RunOnMain([callbackObjPtr , arg0, arg1]() {
                TryCatch tryCatch;
              
                Handle<Value> error;

                Handle<Value> wrappedArg0 = WrapGeolocator(arg0);
                Handle<Value> wrappedArg1 = WrapStatusChangedEventArgs(arg1);

                if (tryCatch.HasCaught())
                {
                  error = tryCatch.Exception()->ToObject();
                }
                else 
                {
                  error = Undefined();
                }


                if (wrappedArg0.IsEmpty()) wrappedArg0 = Undefined();
                if (wrappedArg1.IsEmpty()) wrappedArg1 = Undefined();

                Handle<Value> args[] = { wrappedArg0, wrappedArg1 };
                NodeRT::Utils::CallCallbackInDomain(*callbackObjPtr, _countof(args), args);
              });
            })
          );
        }
        catch (Platform::Exception ^exception)
        {
          NodeRT::Utils::ThrowWinRtExceptionInJs(exception);
          return scope.Close(Undefined());
        }

      }
      else 
      {
        ThrowException(Exception::Error(String::Concat(NodeRT::Utils::NewString(L"given event name isn't supported: "), args[0].As<String>())));
        return scope.Close(Undefined());
      }

      Local<Value> tokenMap = callback->GetHiddenValue(String::NewSymbol(REGISTRATION_TOKEN_MAP_PROPERTY_NAME));
                
      if (tokenMap.IsEmpty() || tokenMap->Equals(Undefined()))
      {
          tokenMap = Object::New();
          callback->SetHiddenValue(String::NewSymbol(REGISTRATION_TOKEN_MAP_PROPERTY_NAME), tokenMap);
      }

      tokenMap.As<Object>()->Set(args[1], CreateOpaqueWrapper(::Windows::Foundation::PropertyValue::CreateInt64(registrationToken.Value)));
                
      return scope.Close(Undefined());
    }

    static v8::Handle<v8::Value> RemoveListener(const v8::Arguments& args)
    {
      HandleScope scope;

      if (args.Length() < 2 || !args[0]->IsString() || !args[1]->IsFunction())
      {
        ThrowException(Exception::Error(NodeRT::Utils::NewString(L"wrong arguments, expected a string and a callback")));
        return scope.Close(Undefined());
      }

      String::Value eventName(args[0]);
      auto str = *eventName;

      if ((NodeRT::Utils::CaseInsenstiveEquals(L"positionChanged", str)) &&(NodeRT::Utils::CaseInsenstiveEquals(L"statusChanged", str)))
      {
        ThrowException(Exception::Error(String::Concat(NodeRT::Utils::NewString(L"given event name isn't supported: "), args[0].As<String>())));
        return scope.Close(Undefined());
      }

      Local<Function> callback = args[1].As<Function>();
      Handle<Value> tokenMap = callback->GetHiddenValue(String::NewSymbol(REGISTRATION_TOKEN_MAP_PROPERTY_NAME));
                
      if (tokenMap.IsEmpty() || tokenMap->Equals(Undefined()))
      {
        return scope.Close(Undefined());
      }

      Handle<Value> opaqueWrapperObj =  tokenMap.As<Object>()->Get(args[1]);

      if (opaqueWrapperObj.IsEmpty() || opaqueWrapperObj->Equals(Undefined()))
      {
        return scope.Close(Undefined());
      }

      OpaqueWrapper *opaqueWrapper = OpaqueWrapper::Unwrap<OpaqueWrapper>(opaqueWrapperObj.As<Object>());
            
      long long tokenValue = (long long) opaqueWrapper->GetObjectInstance();
      ::Windows::Foundation::EventRegistrationToken registrationToken;
      registrationToken.Value = tokenValue;
        
      try 
      {
        if (NodeRT::Utils::CaseInsenstiveEquals(L"positionChanged", str))
        {
          if (!NodeRT::Utils::IsWinRtWrapperOf<::Windows::Devices::Geolocation::Geolocator^>(args.This()))
          {
            ThrowException(Exception::Error(NodeRT::Utils::NewString(L"The caller of this method isn't of the expected type or internal WinRt object was disposed")));
            return scope.Close(Undefined());
          }
          Geolocator *wrapper = Geolocator::Unwrap<Geolocator>(args.This());
          wrapper->_instance->PositionChanged::remove(registrationToken);
        }
        else if (NodeRT::Utils::CaseInsenstiveEquals(L"statusChanged", str))
        {
          if (!NodeRT::Utils::IsWinRtWrapperOf<::Windows::Devices::Geolocation::Geolocator^>(args.This()))
          {
            ThrowException(Exception::Error(NodeRT::Utils::NewString(L"The caller of this method isn't of the expected type or internal WinRt object was disposed")));
            return scope.Close(Undefined());
          }
          Geolocator *wrapper = Geolocator::Unwrap<Geolocator>(args.This());
          wrapper->_instance->StatusChanged::remove(registrationToken);
        }
      }
      catch (Platform::Exception ^exception)
      {
        NodeRT::Utils::ThrowWinRtExceptionInJs(exception);
      }

      tokenMap.As<Object>()->Delete(args[0].As<String>());

      return scope.Close(Undefined());
    }
  private:
    ::Windows::Devices::Geolocation::Geolocator^ _instance;
    static Persistent<FunctionTemplate> s_constructorTemplate;

    friend v8::Handle<v8::Value> WrapGeolocator(::Windows::Devices::Geolocation::Geolocator^ wintRtInstance);
    friend ::Windows::Devices::Geolocation::Geolocator^ UnwrapGeolocator(Handle<Value> value);
    friend bool IsGeolocatorWrapper(Handle<Value> value);
  };
  Persistent<FunctionTemplate> Geolocator::s_constructorTemplate;

  v8::Handle<v8::Value> WrapGeolocator(::Windows::Devices::Geolocation::Geolocator^ winRtInstance)
  {
    HandleScope scope;

    if (winRtInstance == nullptr)
    {
      return scope.Close(Undefined());
    }

    Handle<Object> opaqueWrapper = CreateOpaqueWrapper(winRtInstance);
    Handle<Value> args[] = {opaqueWrapper};
    return scope.Close(Geolocator::s_constructorTemplate->GetFunction()->NewInstance(_countof(args), args));
  }

  ::Windows::Devices::Geolocation::Geolocator^ UnwrapGeolocator(Handle<Value> value)
  {
     return Geolocator::Unwrap<Geolocator>(value.As<Object>())->_instance;
  }

  void InitGeolocator(Handle<Object> exports)
  {
    Geolocator::Init(exports);
  }

  class Geocircle : public WrapperBase
  {
  public:    
    static v8::Handle<v8::Value> Init(const Handle<Object> exports)
    {
      HandleScope scope;
      
      s_constructorTemplate = Persistent<FunctionTemplate>::New(FunctionTemplate::New(New));
      s_constructorTemplate->SetClassName(String::NewSymbol("Geocircle"));
      s_constructorTemplate->InstanceTemplate()->SetInternalFieldCount(1);
      
                              
      s_constructorTemplate->PrototypeTemplate()->SetAccessor(String::NewSymbol("center"), CenterGetter);
      s_constructorTemplate->PrototypeTemplate()->SetAccessor(String::NewSymbol("radius"), RadiusGetter);
      s_constructorTemplate->PrototypeTemplate()->SetAccessor(String::NewSymbol("altitudeReferenceSystem"), AltitudeReferenceSystemGetter);
      s_constructorTemplate->PrototypeTemplate()->SetAccessor(String::NewSymbol("geoshapeType"), GeoshapeTypeGetter);
      s_constructorTemplate->PrototypeTemplate()->SetAccessor(String::NewSymbol("spatialReferenceId"), SpatialReferenceIdGetter);
      
      Local<Function> constructor = s_constructorTemplate->GetFunction();


      exports->Set(String::NewSymbol("Geocircle"), constructor);
      return scope.Close(Undefined());
    }


    virtual ::Platform::Object^ GetObjectInstance() const override
    {
      return _instance;
    }

  private:
    
    Geocircle(::Windows::Devices::Geolocation::Geocircle^ instance)
    {
      _instance = instance;
    }
    
    
    static v8::Handle<v8::Value> New(const v8::Arguments& args)
    {
      HandleScope scope;
      
      ::Windows::Devices::Geolocation::Geocircle^ winRtInstance;


      if (args.Length() == 1 && OpaqueWrapper::IsOpaqueWrapper(args[0]) &&
        NodeRT::Utils::IsWinRtWrapperOf<::Windows::Devices::Geolocation::Geocircle^>(args[0]))
      {
        try 
        {
          winRtInstance = (::Windows::Devices::Geolocation::Geocircle^) NodeRT::Utils::GetObjectInstance(args[0]);
        }
        catch (Platform::Exception ^exception)
        {
          NodeRT::Utils::ThrowWinRtExceptionInJs(exception);
          return scope.Close(Undefined());
        }
      }
      else if (args.Length() == 2
        && IsBasicGeopositionJsObject(args[0])
        && args[1]->IsNumber())
      {
        try
        {
          ::Windows::Devices::Geolocation::BasicGeoposition arg0 = BasicGeopositionFromJsObject(args[0]);
          double arg1 = args[1]->NumberValue();
          
          winRtInstance = ref new ::Windows::Devices::Geolocation::Geocircle(arg0,arg1);
        }
        catch (Platform::Exception ^exception)
        {
          NodeRT::Utils::ThrowWinRtExceptionInJs(exception);
          return scope.Close(Undefined());
        }
      }
      else if (args.Length() == 3
        && IsBasicGeopositionJsObject(args[0])
        && args[1]->IsNumber()
        && args[2]->IsInt32())
      {
        try
        {
          ::Windows::Devices::Geolocation::BasicGeoposition arg0 = BasicGeopositionFromJsObject(args[0]);
          double arg1 = args[1]->NumberValue();
          ::Windows::Devices::Geolocation::AltitudeReferenceSystem arg2 = static_cast<::Windows::Devices::Geolocation::AltitudeReferenceSystem>(args[2]->Int32Value());
          
          winRtInstance = ref new ::Windows::Devices::Geolocation::Geocircle(arg0,arg1,arg2);
        }
        catch (Platform::Exception ^exception)
        {
          NodeRT::Utils::ThrowWinRtExceptionInJs(exception);
          return scope.Close(Undefined());
        }
      }
      else if (args.Length() == 4
        && IsBasicGeopositionJsObject(args[0])
        && args[1]->IsNumber()
        && args[2]->IsInt32()
        && args[3]->IsUint32())
      {
        try
        {
          ::Windows::Devices::Geolocation::BasicGeoposition arg0 = BasicGeopositionFromJsObject(args[0]);
          double arg1 = args[1]->NumberValue();
          ::Windows::Devices::Geolocation::AltitudeReferenceSystem arg2 = static_cast<::Windows::Devices::Geolocation::AltitudeReferenceSystem>(args[2]->Int32Value());
          unsigned int arg3 = static_cast<unsigned int>(args[3]->IntegerValue());
          
          winRtInstance = ref new ::Windows::Devices::Geolocation::Geocircle(arg0,arg1,arg2,arg3);
        }
        catch (Platform::Exception ^exception)
        {
          NodeRT::Utils::ThrowWinRtExceptionInJs(exception);
          return scope.Close(Undefined());
        }
      }
      else
      {
        ThrowException(Exception::Error(NodeRT::Utils::NewString(L"Invalid arguments, no suitable constructor found")));
        return scope.Close(Undefined());
      }

      args.This()->SetHiddenValue(String::NewSymbol("__winRtInstance__"), True());

      Geocircle *wrapperInstance = new Geocircle(winRtInstance);
      wrapperInstance->Wrap(args.This());

      return args.This();
    }


  



    static Handle<Value> CenterGetter(Local<String> property, const AccessorInfo &info)
    {
      HandleScope scope;
      
      if (!NodeRT::Utils::IsWinRtWrapperOf<::Windows::Devices::Geolocation::Geocircle^>(info.This()))
      {
        return scope.Close(Undefined());
      }

      Geocircle *wrapper = Geocircle::Unwrap<Geocircle>(info.This());

      try 
      {
        ::Windows::Devices::Geolocation::BasicGeoposition result = wrapper->_instance->Center;
        return scope.Close(BasicGeopositionToJsObject(result));
      }
      catch (Platform::Exception ^exception)
      {
        NodeRT::Utils::ThrowWinRtExceptionInJs(exception);
        return scope.Close(Undefined());
      }
    }
    
    static Handle<Value> RadiusGetter(Local<String> property, const AccessorInfo &info)
    {
      HandleScope scope;
      
      if (!NodeRT::Utils::IsWinRtWrapperOf<::Windows::Devices::Geolocation::Geocircle^>(info.This()))
      {
        return scope.Close(Undefined());
      }

      Geocircle *wrapper = Geocircle::Unwrap<Geocircle>(info.This());

      try 
      {
        double result = wrapper->_instance->Radius;
        return scope.Close(Number::New(static_cast<double>(result)));
      }
      catch (Platform::Exception ^exception)
      {
        NodeRT::Utils::ThrowWinRtExceptionInJs(exception);
        return scope.Close(Undefined());
      }
    }
    
    static Handle<Value> AltitudeReferenceSystemGetter(Local<String> property, const AccessorInfo &info)
    {
      HandleScope scope;
      
      if (!NodeRT::Utils::IsWinRtWrapperOf<::Windows::Devices::Geolocation::Geocircle^>(info.This()))
      {
        return scope.Close(Undefined());
      }

      Geocircle *wrapper = Geocircle::Unwrap<Geocircle>(info.This());

      try 
      {
        ::Windows::Devices::Geolocation::AltitudeReferenceSystem result = wrapper->_instance->AltitudeReferenceSystem;
        return scope.Close(Integer::New(static_cast<int>(result)));
      }
      catch (Platform::Exception ^exception)
      {
        NodeRT::Utils::ThrowWinRtExceptionInJs(exception);
        return scope.Close(Undefined());
      }
    }
    
    static Handle<Value> GeoshapeTypeGetter(Local<String> property, const AccessorInfo &info)
    {
      HandleScope scope;
      
      if (!NodeRT::Utils::IsWinRtWrapperOf<::Windows::Devices::Geolocation::Geocircle^>(info.This()))
      {
        return scope.Close(Undefined());
      }

      Geocircle *wrapper = Geocircle::Unwrap<Geocircle>(info.This());

      try 
      {
        ::Windows::Devices::Geolocation::GeoshapeType result = wrapper->_instance->GeoshapeType;
        return scope.Close(Integer::New(static_cast<int>(result)));
      }
      catch (Platform::Exception ^exception)
      {
        NodeRT::Utils::ThrowWinRtExceptionInJs(exception);
        return scope.Close(Undefined());
      }
    }
    
    static Handle<Value> SpatialReferenceIdGetter(Local<String> property, const AccessorInfo &info)
    {
      HandleScope scope;
      
      if (!NodeRT::Utils::IsWinRtWrapperOf<::Windows::Devices::Geolocation::Geocircle^>(info.This()))
      {
        return scope.Close(Undefined());
      }

      Geocircle *wrapper = Geocircle::Unwrap<Geocircle>(info.This());

      try 
      {
        unsigned int result = wrapper->_instance->SpatialReferenceId;
        return scope.Close(Integer::New(result));
      }
      catch (Platform::Exception ^exception)
      {
        NodeRT::Utils::ThrowWinRtExceptionInJs(exception);
        return scope.Close(Undefined());
      }
    }
    


  private:
    ::Windows::Devices::Geolocation::Geocircle^ _instance;
    static Persistent<FunctionTemplate> s_constructorTemplate;

    friend v8::Handle<v8::Value> WrapGeocircle(::Windows::Devices::Geolocation::Geocircle^ wintRtInstance);
    friend ::Windows::Devices::Geolocation::Geocircle^ UnwrapGeocircle(Handle<Value> value);
    friend bool IsGeocircleWrapper(Handle<Value> value);
  };
  Persistent<FunctionTemplate> Geocircle::s_constructorTemplate;

  v8::Handle<v8::Value> WrapGeocircle(::Windows::Devices::Geolocation::Geocircle^ winRtInstance)
  {
    HandleScope scope;

    if (winRtInstance == nullptr)
    {
      return scope.Close(Undefined());
    }

    Handle<Object> opaqueWrapper = CreateOpaqueWrapper(winRtInstance);
    Handle<Value> args[] = {opaqueWrapper};
    return scope.Close(Geocircle::s_constructorTemplate->GetFunction()->NewInstance(_countof(args), args));
  }

  ::Windows::Devices::Geolocation::Geocircle^ UnwrapGeocircle(Handle<Value> value)
  {
     return Geocircle::Unwrap<Geocircle>(value.As<Object>())->_instance;
  }

  void InitGeocircle(Handle<Object> exports)
  {
    Geocircle::Init(exports);
  }

} } } } 

void init(Handle<Object> exports)
{
  if (FAILED(CoInitializeEx(nullptr, COINIT_MULTITHREADED)))
  {
    ThrowException(v8::Exception::Error(NodeRT::Utils::NewString(L"error in CoInitializeEx()")));
    return;
  }
  
  NodeRT::Windows::Devices::Geolocation::InitPositionAccuracyEnum(exports);
  NodeRT::Windows::Devices::Geolocation::InitPositionStatusEnum(exports);
  NodeRT::Windows::Devices::Geolocation::InitPositionSourceEnum(exports);
  NodeRT::Windows::Devices::Geolocation::InitGeoshapeTypeEnum(exports);
  NodeRT::Windows::Devices::Geolocation::InitAltitudeReferenceSystemEnum(exports);
  NodeRT::Windows::Devices::Geolocation::InitIGeoshape(exports);
  NodeRT::Windows::Devices::Geolocation::InitGeopoint(exports);
  NodeRT::Windows::Devices::Geolocation::InitGeocoordinateSatelliteData(exports);
  NodeRT::Windows::Devices::Geolocation::InitGeocoordinate(exports);
  NodeRT::Windows::Devices::Geolocation::InitCivicAddress(exports);
  NodeRT::Windows::Devices::Geolocation::InitGeoposition(exports);
  NodeRT::Windows::Devices::Geolocation::InitPositionChangedEventArgs(exports);
  NodeRT::Windows::Devices::Geolocation::InitStatusChangedEventArgs(exports);
  NodeRT::Windows::Devices::Geolocation::InitGeolocator(exports);
  NodeRT::Windows::Devices::Geolocation::InitGeocircle(exports);

  NodeRT::Utils::RegisterNameSpace("Windows.Devices.Geolocation", exports);
}


NODE_MODULE(NodeRT_Windows_Devices_Geolocation, init)