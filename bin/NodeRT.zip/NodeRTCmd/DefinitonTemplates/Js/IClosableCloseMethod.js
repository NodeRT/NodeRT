﻿cls.prototype.@(Model.Name) = function @(Model.Name)() {
}

